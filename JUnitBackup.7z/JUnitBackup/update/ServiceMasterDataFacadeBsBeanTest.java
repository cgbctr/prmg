package com.daimler.soe.dialogfacade.services.business.service;

import static org.easymock.EasyMock.replay;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import org.dbunit.DatabaseUnitException;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.capgemini.psp.server.test.Environment;
import com.capgemini.psp.server.test.EnvironmentType;
import com.daimler.soe.changesession.changesession.business.service.ChangeSessionBs;
import com.daimler.soe.changesession.changesession.business.service.DataLockedByAnotherUserException;
import com.daimler.soe.changesession.services.business.service.ServiceChangeSessionDTO;
import com.daimler.soe.changesession.services.business.service.ServiceMasterChangeSessionDTO;
import com.daimler.soe.changesession.services.business.service.ServiceMasterForOverviewChangeSessionRDTO;
import com.daimler.soe.changesession.services.business.service.VehicleSelectionChangeSessionDTO;
import com.daimler.soe.dialogfacade.services.transformation.ServiceAssignmentRuleOverviewRDTOMapper;
import com.daimler.soe.dialogfacade.vehicleproduct.business.service.VehicleProductFacadeBsBeanTest;
import com.daimler.soe.foundation.authorizationsupport.business.service.RoleOrRightNotFoundException;
import com.daimler.soe.foundation.authorizationsupport.business.service.ServiceAuthorizationDTO;
import com.daimler.soe.foundation.base.enums.BusinessAreaEnum;
import com.daimler.soe.foundation.base.enums.ProductGroupEnum;
import com.daimler.soe.foundation.base.exceptions.EntityStillReferencedException;
import com.daimler.soe.foundation.base.exceptions.ODCGeneralErrorException;
import com.daimler.soe.foundation.base.exceptions.VehicleNotFoundException;
import com.daimler.soe.foundation.changesession.ChangeSessionOperation;
import com.daimler.soe.foundation.changesession.ChangedInSessionEnum;
import com.daimler.soe.foundation.psp.server.test.PspMocker;
import com.daimler.soe.services.servicemasterdata.business.service.AndTermSarDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ContractStartTriggerEnum;
import com.daimler.soe.services.servicemasterdata.business.service.OrTermSarDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceAndMatchedSelectionsCDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceBusinessAreaEnum;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceDataRetrieveStrategy;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterAlreadyExistsException;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterAndAuthorisationCDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterDataBs;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterDataRetrieveStrategy;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterDataUiBs;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterForOverviewRDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceMasterPartialDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServiceRDTO;
import com.daimler.soe.services.servicemasterdata.business.service.ServicesAndMatchedSelectionsCDTO;
import com.daimler.soe.services.servicemasterdata.business.service.TestMatchedRulesAndEquipmentCodesRTO;
import com.daimler.soe.services.servicemasterdata.business.service.VehicleSelectionTestSimulationPTO;
import com.daimler.soe.services.servicemasterdata.business.service.VehicleSelectionTestSimulationRTO;
import com.daimler.soe.services.testdata.ServiceMasterTestSet;
import com.daimler.soe.services.testdata.ServicesTestSet;
import com.daimler.soe.techbase.dtos.NameI18NDTO;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.business.service.SalesTypeDTO;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.business.service.VehicleProductMasterDataBs;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.business.service.VehicleTypeEnum;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionDTO;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionDataRetrieveStrategy;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionsTestSourcesEnum;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.testdata.VehicleSelectionTestSet;
import com.google.common.collect.Lists;

import dcx.tools.util.common.text.StringUtil;

@Environment(type = EnvironmentType.PLAIN, scenario = "com.daimler.soe.dialogfacade.services")
@Category(com.daimler.soe.foundation.junit.categories.UnitTestCategory.class)
public class ServiceMasterDataFacadeBsBeanTest {

    private static final ProductGroupEnum PRODUCT_GROUP_P = ProductGroupEnum.P;

    /**
     * Entity that created the object
     */
    private static final String CREATED_BY = "John Doe I";

    /**
     * Entity that modified the object
     */
    private static final String MODIFIED_BY = "John Doe II";

    /** Equipment code for tests 111. */
    private static final String EQUIPMENT_CODE_111 = "111";

    /** Equipment code for tests 222. */
    private static final String EQUIPMENT_CODE_222 = "222";

    /**
     * Creation date of the model series
     */
    private static final Date CREATION_DATE = new Date(123456);

    /**
     * Internationalization texts
     */
    private static final Map<String, NameI18NDTO> I18NTEXTS = createI18NTexts();

    /**
     * Service authorisation
     */
    private static final ServiceRDTO SERVICE_RDTO = createServiceRDTO();

    /**
     * Service session
     */
    private static final ServiceChangeSessionDTO SERVICE_CS_DTO = createServiceChangeSessionDTO();

    /**
     * List of services
     */
    private static final List<ServiceChangeSessionDTO> SERVICE_CS_LIST_DTO = createServiceChangeSessionList();

    /** The mocker. */
    @Rule
    public PspMocker mocker = new PspMocker();

    private ServiceMasterDataFacadeBs serviceMasterDataFacadeBs;

    /**
     * Initialize objects and resources.
     *
     * @throws SQLException may be thrown
     * @throws DatabaseUnitException may be thrown
     * @throws DataLockedByAnotherUserException
     */
    @Before
    public void setUp() throws DatabaseUnitException, SQLException, DataLockedByAnotherUserException {
        this.serviceMasterDataFacadeBs = new ServiceMasterDataFacadeBsBean();

        ServiceMasterTestSet.reset();
        ServicesTestSet.reset();
    }

    /**
     * clean up everything.
     *
     * @throws DatabaseUnitException exception that might get thrown
     * @throws SQLException exception exception that might get thrown
     */
    @After
    public void tearDown() throws DatabaseUnitException, SQLException {
    }

    @Test
    public void testGetServices() {

        // Mock ChangeSessionBs
        ServiceMasterDataBs serviceMasterDataBsMock = EasyMock.createMock(ServiceMasterDataBs.class);
        EasyMock.expect(serviceMasterDataBsMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
                .andReturn(new ArrayList<ServiceDTO>()).once();
        replay(serviceMasterDataBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataBsMock);

        ChangeSessionBs changeSessionBsMock = EasyMock.createNiceMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForAllUsers(ServiceChangeSessionDTO.class))
                .andStubReturn(SERVICE_CS_LIST_DTO);
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        // Method call to test
        List<ServiceChangeSessionDTO> services = serviceMasterDataFacadeBs.getServices();

        assertTrue(services.size() == 1);
        // Verify
        EasyMock.verify(changeSessionBsMock);
        EasyMock.verify(serviceMasterDataBsMock);
    }

    @Test
    public void testCopyAndTerm() {
        // #region TestData - create testdata because dont want to insert a dependency for ServiceImpl
        List<AndTermSarDTO> andTermList = new ArrayList<AndTermSarDTO>();
        AndTermSarDTO andTermDto = new AndTermSarDTO();
        OrTermSarDTO orTermDto = new OrTermSarDTO();
        orTermDto.setEquipmentCode(EQUIPMENT_CODE_111);
        orTermDto.setEquipmentCodeProductGroup(PRODUCT_GROUP_P);
        orTermDto.setNegated(false);
        OrTermSarDTO orTermDto2 = new OrTermSarDTO();
        orTermDto2.setEquipmentCode(EQUIPMENT_CODE_222);
        orTermDto2.setEquipmentCodeProductGroup(PRODUCT_GROUP_P);
        orTermDto2.setNegated(false);
        andTermDto.setOrTerms(Arrays.asList(orTermDto, orTermDto2));
        andTermList.add(andTermDto);
        // #endregion TestData
        List<AndTermSarDTO> copyOfAndTermsList =
                ServiceAssignmentRuleOverviewRDTOMapper.copyOfAndTermsList(andTermList);
        Assert.assertTrue(copyOfAndTermsList.containsAll(andTermList));
    }

    @Test
    public void testBuildServiceDataRetrieveStrategy() {
        // Mock ServiceMasterDataBs
        ServiceMasterDataBs serviceMasterDataMock = EasyMock.createNiceMock(ServiceMasterDataBs.class);
        EasyMock.expect(serviceMasterDataMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
                .andReturn(new ArrayList<ServiceDTO>());
        replay(serviceMasterDataMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataMock);

        // Mock ChangeSessionBs
        ChangeSessionBs changeSessionBsMock = EasyMock.createNiceMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceChangeSessionDTO.class))
                .andReturn(Arrays.asList(new ServiceChangeSessionDTO(new ServiceRDTO()))).anyTimes();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        ServiceDataRetrieveStrategy serviceDataRetrieveStrategy =
                serviceMasterDataFacadeBs.buildServiceDataRetrieveStrategy();
        Assert.assertNotNull(serviceDataRetrieveStrategy);
        // Verify
        EasyMock.verify(serviceMasterDataMock);
        EasyMock.verify(changeSessionBsMock);
    }

    @Test
    public void testBuildVehicleSelectionDataRetrieveStrategy() {

        // Mock ServiceMasterDataBs
        VehicleProductMasterDataBs serviceMasterDataMock = EasyMock.createNiceMock(VehicleProductMasterDataBs.class);
        EasyMock.expect(serviceMasterDataMock.getVehicleSelectionsOverview())
                .andReturn(Arrays.asList(new VehicleSelectionDTO()));
        replay(serviceMasterDataMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataMock);

        // Mock ChangeSessionBs
        ChangeSessionBs changeSessionBsMock = EasyMock.createNiceMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForUser(VehicleSelectionChangeSessionDTO.class))
                .andReturn(Arrays.asList(new VehicleSelectionChangeSessionDTO(new VehicleSelectionDTO())));

        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        // Method call to test
        VehicleSelectionDataRetrieveStrategy strategy =
                serviceMasterDataFacadeBs.buildVehicleSelectionDataRetrieveStrategy();

        Assert.assertNotNull(strategy);
        // Verify
        EasyMock.verify(serviceMasterDataMock);
        EasyMock.verify(changeSessionBsMock);
    }

    @Test
    public void testResolveInputData() throws ODCGeneralErrorException, VehicleNotFoundException {

        // Mock ServiceMasterDataBs
        VehicleProductMasterDataBs vehicleProductMasterDataMock =
                EasyMock.createNiceMock(VehicleProductMasterDataBs.class);
        EasyMock.expect(vehicleProductMasterDataMock.getVehicleSelectionsOverview())
                .andReturn(Arrays.asList(new VehicleSelectionDTO())).anyTimes();
        replay(vehicleProductMasterDataMock);
        mocker.setMock(serviceMasterDataFacadeBs, vehicleProductMasterDataMock);
        ServiceMasterDataBs serviceMasterDataMock = EasyMock.createNiceMock(ServiceMasterDataBs.class);

        EasyMock.expect(serviceMasterDataMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
                .andReturn(new ArrayList<ServiceDTO>()).anyTimes();
        EasyMock.expect(
                serviceMasterDataMock.testVehicleSelections(EasyMock.anyObject(VehicleSelectionTestSimulationPTO.class),
                        EasyMock.anyObject(VehicleSelectionDataRetrieveStrategy.class),
                        EasyMock.anyObject(ServiceDataRetrieveStrategy.class),
                        EasyMock.anyObject(ServiceMasterDataRetrieveStrategy.class)))
                .andReturn(new ServicesAndMatchedSelectionsCDTO()).anyTimes();

        EasyMock.expect(serviceMasterDataMock.getAllServiceMasters()).andReturn(new ArrayList<ServiceMasterDTO>())
                .anyTimes();
        replay(serviceMasterDataMock);

        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataMock);

        // Mock ChangeSessionBs
        ChangeSessionBs changeSessionBsMock = EasyMock.createNiceMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForUser(VehicleSelectionChangeSessionDTO.class))
                .andReturn(Arrays.asList(new VehicleSelectionChangeSessionDTO(new VehicleSelectionDTO()))).anyTimes();

        EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceChangeSessionDTO.class))
                .andReturn(Arrays.asList(new ServiceChangeSessionDTO(new ServiceRDTO()))).anyTimes();
        EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceMasterChangeSessionDTO.class)).andReturn(Arrays
                .asList(new ServiceMasterChangeSessionDTO(new ServiceMasterAndAuthorisationCDTO(new ServiceMasterDTO(),
                        new ArrayList<ServiceAuthorizationDTO>()))))
                .anyTimes();

        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        VehicleSelectionTestSimulationPTO testSimulatorDto = new VehicleSelectionTestSimulationPTO();
        testSimulatorDto.setVin("FIN");
        testSimulatorDto.setSelectedSource(VehicleSelectionsTestSourcesEnum.PRODUCTIVE);
        testSimulatorDto.setVinAvailable(true);
        testSimulatorDto.setAddressCountryCode("addressCountryCode");
        testSimulatorDto.setConsumerCountryCode("consumerCountryCode");
        testSimulatorDto.setSimulationDate(new Date());
        testSimulatorDto.setModelSeriesId("seriesid");
        testSimulatorDto.setModelYearCode("modelyear");
        testSimulatorDto.setChangeYearCodes(Lists.newArrayList("123", "234"));
        testSimulatorDto.setEquipmentCodes(new HashSet<String>());
        testSimulatorDto.setLocale(Locale.GERMANY);
        testSimulatorDto.setSalesTypeDto(new SalesTypeDTO());

        // VehicleSelectionTestSimulationRTO
        TestMatchedRulesAndEquipmentCodesRTO testMatchedRulesAndEquipmentCodesRTO1 =
                new TestMatchedRulesAndEquipmentCodesRTO();
        testMatchedRulesAndEquipmentCodesRTO1.setEquipmentCodes(EQUIPMENT_CODE_111);
        testMatchedRulesAndEquipmentCodesRTO1.setServiceAssignmentRuleBusinessKey("LiveTraficRule");

        TestMatchedRulesAndEquipmentCodesRTO testMatchedRulesAndEquipmentCodesRTO2 =
                new TestMatchedRulesAndEquipmentCodesRTO();
        testMatchedRulesAndEquipmentCodesRTO1.setEquipmentCodes(EQUIPMENT_CODE_222);
        testMatchedRulesAndEquipmentCodesRTO1.setServiceAssignmentRuleBusinessKey("LiveTraficRule2");

        List<TestMatchedRulesAndEquipmentCodesRTO> testMatchedRulesAndEquipmentCodesRTOList =
                new ArrayList<TestMatchedRulesAndEquipmentCodesRTO>();
        testMatchedRulesAndEquipmentCodesRTOList.add(testMatchedRulesAndEquipmentCodesRTO1);
        testMatchedRulesAndEquipmentCodesRTOList.add(testMatchedRulesAndEquipmentCodesRTO2);

        HashSet<String> dataSet1 = new HashSet<String>(Arrays.asList("360", "820", "569"));
        HashSet<String> dataSet2 = new HashSet<String>(Arrays.asList("520", "820", "569"));

        Map<String, Set<String>> matchedSelectionsAndEquipmentCodes = new HashMap<String, Set<String>>();
        matchedSelectionsAndEquipmentCodes.put("TestVehicleSelection-1", dataSet1);
        matchedSelectionsAndEquipmentCodes.put("TestVehicleSelection-2", dataSet2);
        ServiceAndMatchedSelectionsCDTO serviceAndMatchedSelectionsCDTO = new ServiceAndMatchedSelectionsCDTO();
        serviceAndMatchedSelectionsCDTO.setServicePartialDTO(ServicesTestSet.BASIC_SERVICES_PARTIAL_DATA);
        serviceAndMatchedSelectionsCDTO.setMatchedSelectionsAndEquipmentCodes(matchedSelectionsAndEquipmentCodes);

        Set<ServiceAndMatchedSelectionsCDTO> matchedServicesSelectionsEquipmentcodes =
                new HashSet<ServiceAndMatchedSelectionsCDTO>();

        matchedServicesSelectionsEquipmentcodes.add(serviceAndMatchedSelectionsCDTO);

        ServicesAndMatchedSelectionsCDTO servicesAndMatchedSelectionsCDTO = new ServicesAndMatchedSelectionsCDTO();
        servicesAndMatchedSelectionsCDTO.setMatchedServicesRulesEquipmentcodes(matchedServicesSelectionsEquipmentcodes);
        servicesAndMatchedSelectionsCDTO.setVehicleType(VehicleTypeEnum.CONNECT_VEHICLE);

        Set<ServiceAndMatchedSelectionsCDTO> ServiceAndMatchedSelectionsCDTOSet =
                new HashSet<ServiceAndMatchedSelectionsCDTO>();
        ServiceAndMatchedSelectionsCDTOSet.add(serviceAndMatchedSelectionsCDTO);

        //
        VehicleSelectionTestSimulationRTO vehicleSelectionTestSimulationRTO = new VehicleSelectionTestSimulationRTO(20L,
                I18NTEXTS, 20, BusinessAreaEnum.B2B, testMatchedRulesAndEquipmentCodesRTOList);

        List<VehicleSelectionTestSimulationRTO> resultList = new ArrayList<VehicleSelectionTestSimulationRTO>();
        resultList.add(vehicleSelectionTestSimulationRTO);
        testSimulatorDto.setResultList(resultList);

        // Method call to test
        VehicleSelectionTestSimulationPTO vehicleSelectionTestSimulationDTO =
                serviceMasterDataFacadeBs.executeTestSimulation(testSimulatorDto);

        Assert.assertNotNull(vehicleSelectionTestSimulationDTO);
        Assert.assertNotNull(vehicleSelectionTestSimulationDTO.getModelSeriesId());

        // Method call to test after SRS-30
        testSimulatorDto.setModelSeriesId(StringUtil.EMPTY_STRING);
        vehicleSelectionTestSimulationDTO = serviceMasterDataFacadeBs.executeTestSimulation(testSimulatorDto);

        // Method call to test after SRS-071
        testSimulatorDto.vehicleSelectionTestSimulationDTO =
                serviceMasterDataFacadeBs.executeTestSimulation(testSimulatorDto);

        Assert.assertNotNull(vehicleSelectionTestSimulationDTO);
        Assert.assertTrue("Empty ModelSeriesId", vehicleSelectionTestSimulationDTO.getModelSeriesId().isEmpty());

        // Verify
        EasyMock.verify(serviceMasterDataMock);
        EasyMock.verify(changeSessionBsMock);
    }

    @Test
    public void testResolveInputDataTest() throws ODCGeneralErrorException, VehicleNotFoundException {

        // input for serviceMasterDataBsMock
        HashSet<String> dataSet1 = new HashSet<String>(Arrays.asList("360", "820", "569"));
        HashSet<String> dataSet2 = new HashSet<String>(Arrays.asList("520", "820", "569"));

        Map<String, Set<String>> matchedSelectionsAndEquipmentCodes = new HashMap<String, Set<String>>();
        matchedSelectionsAndEquipmentCodes.put("TestVehicleSelection-1", dataSet1);
        matchedSelectionsAndEquipmentCodes.put("TestVehicleSelection-2", dataSet2);
        ServiceAndMatchedSelectionsCDTO serviceAndMatchedSelectionsCDTO = new ServiceAndMatchedSelectionsCDTO();
        serviceAndMatchedSelectionsCDTO.setServicePartialDTO(ServicesTestSet.BASIC_SERVICES_PARTIAL_DATA);
        serviceAndMatchedSelectionsCDTO.setMatchedSelectionsAndEquipmentCodes(matchedSelectionsAndEquipmentCodes);

        Set<ServiceAndMatchedSelectionsCDTO> matchedServicesSelectionsEquipmentcodes =
                new HashSet<ServiceAndMatchedSelectionsCDTO>();

        matchedServicesSelectionsEquipmentcodes.add(serviceAndMatchedSelectionsCDTO);

        ServicesAndMatchedSelectionsCDTO servicesAndMatchedSelectionsCDTO = new ServicesAndMatchedSelectionsCDTO();
        servicesAndMatchedSelectionsCDTO.setMatchedServicesRulesEquipmentcodes(matchedServicesSelectionsEquipmentcodes);
        servicesAndMatchedSelectionsCDTO.setVehicleType(VehicleTypeEnum.CONNECT_VEHICLE);

        VehicleSelectionTestSimulationPTO testSimulatorDto = new VehicleSelectionTestSimulationPTO();
        testSimulatorDto.setVin("FIN");
        testSimulatorDto.setSelectedSource(VehicleSelectionsTestSourcesEnum.MY_CHANGE_SESSION);
        testSimulatorDto.setVinAvailable(true);
        testSimulatorDto.setAddressCountryCode("addressCountryCode");
        testSimulatorDto.setConsumerCountryCode("consumerCountryCode");
        testSimulatorDto.setSimulationDate(new Date());
        testSimulatorDto.setModelSeriesId("seriesid");
        testSimulatorDto.setModelYearCode("modelyear");
        testSimulatorDto.setChangeYearCodes(Lists.newArrayList("123", "234"));
        testSimulatorDto.setEquipmentCodes(new HashSet<String>());
        testSimulatorDto.setLocale(Locale.GERMANY);
        testSimulatorDto.setSalesTypeDto(new SalesTypeDTO());
        testSimulatorDto.setBusinessArea(ServiceBusinessAreaEnum.B2B);

        List<VehicleSelectionDTO> vehicleSelectionDTOList = VehicleSelectionTestSet.ALL_VEHICLE_SELECTION_DTOS;
        // visibility chagne private to public
        List<VehicleSelectionChangeSessionDTO> vehicleSelectionChangeSessionDTOList =
                VehicleProductFacadeBsBeanTest.createVehicleSelectionChangeSessionList();

        List<ServiceMasterDTO> serviceMasterDTOList = ServiceMasterTestSet.ALL_SERVICEMASTER_DTOS;
        List<ServiceMasterChangeSessionDTO> serviceMasterChangeSessionDTOList =
                ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;
        List<ServiceDTO> serviceDTOList = ServicesTestSet.ALL_REFERENCING_SERVICE_DTOS;

        /*
         * List<Long> serviceIds = Lists.newArrayList(ServicesTestSet.GEOFENCE_SERVICE_1_ID,
         * ServicesTestSet.PREMIUM_SERVICE_1_ID, ServicesTestSet.SPECIAL_SERVICE_ID);
         */

        List<Long> serviceIds = new ArrayList<Long>();
        serviceIds.add(ServicesTestSet.BASIC_SERVICES_ID);
        serviceIds.add(ServicesTestSet.GEOFENCE_SERVICE_1_ID);

        // 3 services, all of them are available in the country "DE".

        List<ServiceMasterPartialDTO> serviceMasterPartialDTOList = new ArrayList<ServiceMasterPartialDTO>();

        ServiceMasterPartialDTO serviceMasterDTO1 = ServiceMasterTestSet.BASIC_SERVICES_SERVICE_MASTER_PARTIAL_DTO;
        serviceMasterDTO1.setBusinessArea(BusinessAreaEnum.B2C);
        serviceMasterPartialDTOList.add(serviceMasterDTO1);
        ServiceMasterPartialDTO serviceMasterDTO2 = ServiceMasterTestSet.GEOFENCE_SERVICES_SERVICE_MASTER_PARTIAL_DTO;
        serviceMasterDTO2.setBusinessArea(BusinessAreaEnum.B2B);
        serviceMasterPartialDTOList.add(serviceMasterDTO2);

        // Mock ServiceMasterDataBs
        ServiceMasterDataBs serviceMasterDataBsMock = EasyMock.createMock(ServiceMasterDataBs.class);
        /*
         * EasyMock.expect(serviceMasterDataBsMock.testVehicleSelections(testSimulatorDto, null, null))
         * .andReturn(servicesAndMatchedSelectionsCDTO);
         */
        EasyMock.expect(serviceMasterDataBsMock.testVehicleSelections(
                EasyMock.anyObject(VehicleSelectionTestSimulationPTO.class),
                EasyMock.anyObject(VehicleSelectionDataRetrieveStrategy.class),
                EasyMock.anyObject(ServiceDataRetrieveStrategy.class),
                EasyMock.anyObject(ServiceMasterDataRetrieveStrategy.class)))
                .andReturn(servicesAndMatchedSelectionsCDTO).anyTimes();
        EasyMock.expect(serviceMasterDataBsMock.getAllServiceMasters()).andReturn(serviceMasterDTOList);
        EasyMock.expect(serviceMasterDataBsMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
                .andReturn(serviceDTOList).anyTimes();
        replay(serviceMasterDataBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataBsMock);

        // create VehicleProductMasterDataBs
        VehicleProductMasterDataBs vehicleProductMasterDataBsMock =
                EasyMock.createMock(VehicleProductMasterDataBs.class);
        EasyMock.expect(vehicleProductMasterDataBsMock.getVehicleSelectionsOverview())
                .andReturn(vehicleSelectionDTOList);// .anyTimes();
        replay(vehicleProductMasterDataBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, vehicleProductMasterDataBsMock);

        // create ChangeSessionBs
        // Mock ChangeSessionBs
        ChangeSessionBs changeSessionBsMock = EasyMock.createNiceMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForUser(VehicleSelectionChangeSessionDTO.class))
                .andReturn(Arrays.asList(new VehicleSelectionChangeSessionDTO(new VehicleSelectionDTO())));

        EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceMasterChangeSessionDTO.class))
                .andReturn(serviceMasterChangeSessionDTOList);
        EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceChangeSessionDTO.class))
                .andReturn(SERVICE_CS_LIST_DTO);

        EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceMasterChangeSessionDTO.class))
                .andReturn(serviceMasterChangeSessionDTOList);
        EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceChangeSessionDTO.class))
                .andReturn(SERVICE_CS_LIST_DTO);
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        // create ServiceMasterDataRetrieveStrategy serviceMasterDataRetrieveStrategymock
        ServiceMasterDataRetrieveStrategy serviceMasterDataRetrieveStrategymock =
                EasyMock.createMock(ServiceMasterDataRetrieveStrategy.class);
        EasyMock.expect(serviceMasterDataRetrieveStrategymock
                .getServiceMasterPartialDTOsByServiceMasterIds(EasyMock.anyObject(List.class)))
                .andReturn(new ArrayList<ServiceMasterPartialDTO>());
        replay(serviceMasterDataRetrieveStrategymock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataRetrieveStrategymock);

        /*
         * // Create Mock ServiceMasterPs serviceMasterPsMock = createMock(ServiceMasterPs.class);
         * EasyMock.expect(serviceMasterPsMock.getServiceMasterPartialDTOsByServiceMasterIds(EasyMock.anyObject(List.
         * class))) .andReturn(new ArrayList<ServiceMasterPartialDTO>()); replay(serviceMasterPsMock);
         * mocker.setMock(serviceMasterDataFacadeBs, serviceMasterPsMock);
         */

        // EntityManager

        /*
         * // create ServiceMasterDataBs ServiceMasterDataBs serviceMasterDataMock =
         * EasyMock.createMock(ServiceMasterDataBs.class); EasyMock.expect(serviceMasterDataMock.getAllServices(null,
         * ServiceBusinessAreaEnum.ALL, false)) .andReturn(serviceDTOList).anyTimes();
         */

        VehicleSelectionTestSimulationPTO vehicleSelectionTestSimulationDTO =
                serviceMasterDataFacadeBs.executeTestSimulation(testSimulatorDto);
        EasyMock.verify(serviceMasterDataBsMock);
        EasyMock.verify(vehicleProductMasterDataBsMock);
        EasyMock.verify(changeSessionBsMock);
        EasyMock.verify(serviceMasterDataRetrieveStrategymock);
        /*
         * ServiceMasterDataBs serviceMasterDataMock = EasyMock.createNiceMock(ServiceMasterDataBs.class);
         * EasyMock.expect(serviceMasterDataMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
         * .andReturn(new ArrayList<ServiceDTO>()).anyTimes(); EasyMock.expect(
         * serviceMasterDataMock.testVehicleSelections(EasyMock.anyObject(VehicleSelectionTestSimulationPTO.class),
         * EasyMock.anyObject(VehicleSelectionDataRetrieveStrategy.class),
         * EasyMock.anyObject(ServiceDataRetrieveStrategy.class))) .andReturn(new
         * ServicesAndMatchedSelectionsCDTO()).anyTimes();
         * EasyMock.expect(serviceMasterDataMock.getAllServiceMasters()).andReturn(new ArrayList<ServiceMasterDTO>())
         * .anyTimes(); replay(serviceMasterDataMock); mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataMock);
         * // Mock ChangeSessionBs ChangeSessionBs changeSessionBsMock = EasyMock.createNiceMock(ChangeSessionBs.class);
         * EasyMock.expect(changeSessionBsMock.getDataForUser(VehicleSelectionChangeSessionDTO.class))
         * .andReturn(Arrays.asList(new VehicleSelectionChangeSessionDTO(new VehicleSelectionDTO()))).anyTimes();
         * EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceChangeSessionDTO.class))
         * .andReturn(Arrays.asList(new ServiceChangeSessionDTO(new ServiceRDTO()))).anyTimes();
         * EasyMock.expect(changeSessionBsMock.getDataForUser(ServiceMasterChangeSessionDTO.class)).andReturn(Arrays
         * .asList(new ServiceMasterChangeSessionDTO(new ServiceMasterAndAuthorisationCDTO(new ServiceMasterDTO(), new
         * ArrayList<ServiceAuthorizationDTO>())))) .anyTimes(); replay(changeSessionBsMock);
         * mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock); EasyMock.verify(changeSessionBsMock);
         */
        /*
         * VehicleSelectionTestSimulationPTO = serviceMasterDataFacadeBs.executeTestSimulation(testSimulatorDto);
         * VehicleSelectionTestSimulationPTO testSimulatorDto = new VehicleSelectionTestSimulationPTO();
         * testSimulatorDto.setVin("FIN");
         * testSimulatorDto.setSelectedSource(VehicleSelectionsTestSourcesEnum.PRODUCTIVE);
         * testSimulatorDto.setVinAvailable(true); testSimulatorDto.setAddressCountryCode("addressCountryCode");
         * testSimulatorDto.setConsumerCountryCode("consumerCountryCode"); testSimulatorDto.setSimulationDate(new
         * Date()); testSimulatorDto.setModelSeriesId("seriesid"); testSimulatorDto.setModelYearCode("modelyear");
         * testSimulatorDto.setChangeYearCodes(Lists.newArrayList("123", "234")); testSimulatorDto.setEquipmentCodes(new
         * HashSet<String>()); testSimulatorDto.setLocale(Locale.GERMANY); testSimulatorDto.setSalesTypeDto(new
         * SalesTypeDTO());
         */

        // Method call to test
        /*
         * VehicleSelectionTestSimulationPTO vehicleSelectionTestSimulationDTO =
         * serviceMasterDataFacadeBs.executeTestSimulation(testSimulatorDto);
         * Assert.assertNotNull(vehicleSelectionTestSimulationDTO);
         * Assert.assertNotNull(vehicleSelectionTestSimulationDTO.getModelSeriesId()); // Method call to test after
         * SRS-30 testSimulatorDto.setModelSeriesId(StringUtil.EMPTY_STRING); vehicleSelectionTestSimulationDTO =
         * serviceMasterDataFacadeBs.executeTestSimulation(testSimulatorDto);
         * Assert.assertNotNull(vehicleSelectionTestSimulationDTO); Assert.assertTrue("Empty ModelSeriesId",
         * vehicleSelectionTestSimulationDTO.getModelSeriesId().isEmpty()); // Verify
         * EasyMock.verify(serviceMasterDataMock); EasyMock.verify(changeSessionBsMock);
         */
    }

    // ************************************************************************
    // Private Helpers
    // ***********************************************************************
    /**
     * ServiceDTO maker
     *
     * @return
     */
    private static ServiceDTO createServiceDTO() {
        ServiceDTO service = new ServiceDTO();
        service.setContractDuration(30);
        service.setContractStartTrigger(ContractStartTriggerEnum.FIRST_REGISTRATION_VEHICLE);
        service.setCreatedBy(CREATED_BY);
        service.setCreationDate(CREATION_DATE);
        service.setId(123456L);
        // service.setModificationDate(MODIFICATION_DATE);
        service.setModifiedBy(MODIFIED_BY);
        service.setNameTexts(I18NTEXTS);
        service.setServiceId(123456L);

        service.setLicenseRequired(false);
        service.setServicePartNumber(null);
        return service;
    }

    private static ServiceRDTO createServiceRDTO() {
        ServiceRDTO service = new ServiceRDTO();
        service.setService(createServiceDTO());
        return service;
    }

    private static ServiceChangeSessionDTO createServiceChangeSessionDTO() {
        ServiceChangeSessionDTO service = new ServiceChangeSessionDTO(SERVICE_RDTO);
        service.setChangedInSession(ChangedInSessionEnum.CURRENT_USERS_CHANGE_SESSION);
        service.setOperation(ChangeSessionOperation.NEW);

        return service;
    }

    private static List<ServiceChangeSessionDTO> createServiceChangeSessionList() {
        return Arrays.asList(SERVICE_CS_DTO);
    }

    private static Map<String, NameI18NDTO> createI18NTexts() {
        Map<String, NameI18NDTO> i18ltexts = new HashMap<String, NameI18NDTO>();
        i18ltexts.put("i18n", new NameI18NDTO("language", "name"));
        return i18ltexts;
    }

    /**
     * Test for get service masters with authorization data.
     */
    @Test
    public void testGetServiceMastersWithAuthorizationData() {

        List<ServiceMasterAndAuthorisationCDTO> productiveList = new ArrayList<ServiceMasterAndAuthorisationCDTO>();
        productiveList.add(ServiceMasterTestSet.BASIC_SERVICEMASTER_AUTH_CDTO);
        List<ServiceMasterChangeSessionDTO> changedList = ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;
        List<ServiceMasterChangeSessionDTO> expectedResult = ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;

        // Create Mock
        ServiceMasterDataUiBs serviceMasterDataUiBsMock = EasyMock.createMock(ServiceMasterDataUiBs.class);
        EasyMock.expect(serviceMasterDataUiBsMock.getServiceMastersWithAuthorizationData()).andReturn(productiveList)
                .once();
        replay(serviceMasterDataUiBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataUiBsMock);

        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForAllUsers(ServiceMasterChangeSessionDTO.class))
                .andReturn(changedList).once();
        EasyMock.expect(changeSessionBsMock.isChangeSessionOpenedForUser()).andReturn(true).anyTimes();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        List<ServiceMasterChangeSessionDTO> actualResult =
                serviceMasterDataFacadeBs.getServiceMastersWithAuthorizationData();

        // Assertion
        EasyMock.verify(serviceMasterDataUiBsMock);
        EasyMock.verify(changeSessionBsMock);
        assertThat(actualResult, equalTo(expectedResult));

    }

    /**
     * Test for get service masters with licenseRequired == true .
     */
    @Test
    public void testGetServiceMastersWithLicenseRequired() {

        List<ServiceMasterAndAuthorisationCDTO> productiveList = new ArrayList<ServiceMasterAndAuthorisationCDTO>();
        productiveList.add(ServiceMasterTestSet.BASIC_SERVICEMASTER_AUTH_CDTO);
        List<ServiceMasterChangeSessionDTO> changedList = ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;
        List<ServiceMasterChangeSessionDTO> expectedResult = ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;

        // Create Mock
        ServiceMasterDataUiBs serviceMasterDataUiBsMock = EasyMock.createMock(ServiceMasterDataUiBs.class);
        EasyMock.expect(serviceMasterDataUiBsMock.getServiceMastersWithLicenseRequired()).andReturn(productiveList)
                .once();
        replay(serviceMasterDataUiBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataUiBsMock);

        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForAllUsers(ServiceMasterChangeSessionDTO.class))
                .andReturn(changedList).once();
        EasyMock.expect(changeSessionBsMock.isChangeSessionOpenedForUser()).andReturn(true).anyTimes();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        List<ServiceMasterChangeSessionDTO> actualResult =
                serviceMasterDataFacadeBs.getServiceMastersWithLicenseRequired();

        // Assertion
        EasyMock.verify(serviceMasterDataUiBsMock);
        EasyMock.verify(changeSessionBsMock);
        assertThat(actualResult, equalTo(expectedResult));

    }

    /**
     * Test for getServiceMastersForOverview().
     */
    @Test
    public void testGetServiceMastersForOverview() {

        List<ServiceMasterForOverviewRDTO> productiveList = new ArrayList<ServiceMasterForOverviewRDTO>();
        productiveList.add(ServiceMasterTestSet.BASIC_SERVICES_SERVICE_MASTER_RDTO);
        List<ServiceMasterChangeSessionDTO> changedList = ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;
        List<ServiceMasterForOverviewChangeSessionRDTO> expectedResult =
                ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_RDTOS;

        // Create Mock
        ServiceMasterDataUiBs serviceMasterDataUiBsMock = EasyMock.createMock(ServiceMasterDataUiBs.class);
        EasyMock.expect(serviceMasterDataUiBsMock.getServiceMastersForOverview()).andReturn(productiveList).once();
        replay(serviceMasterDataUiBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataUiBsMock);

        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        EasyMock.expect(changeSessionBsMock.getDataForAllUsers(ServiceMasterChangeSessionDTO.class))
                .andReturn(changedList).once();
        EasyMock.expect(changeSessionBsMock.isChangeSessionOpenedForUser()).andReturn(true).anyTimes();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        List<ServiceMasterForOverviewChangeSessionRDTO> actualResult =
                serviceMasterDataFacadeBs.getServiceMastersForOverview();

        // Assertion
        EasyMock.verify(serviceMasterDataUiBsMock);
        EasyMock.verify(changeSessionBsMock);
        assertThat(actualResult, equalTo(expectedResult));

    }

    /**
     * Test for new service master.
     *
     * @throws DataLockedByAnotherUserException
     * @throws RoleOrRightNotFoundException
     * @throws ServiceMasterAlreadyExistsException
     */
    @Test
    public void testAddNewServiceMaster() throws DataLockedByAnotherUserException {

        ServiceMasterChangeSessionDTO testData = ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTO;

        // Create Mock
        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        changeSessionBsMock.addDataToChangeSession(ChangeSessionOperation.NEW, ServiceMasterDataUiBs.class, testData);
        EasyMock.expectLastCall().once();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        // test method
        serviceMasterDataFacadeBs.addNewServiceMaster(testData);

        // Assertion
        EasyMock.verify(changeSessionBsMock);

    }

    /**
     * Test for update service master.
     *
     * @throws DataLockedByAnotherUserException
     */
    @Test
    public void testUpdateServiceMaster() throws DataLockedByAnotherUserException {

        ServiceMasterChangeSessionDTO testData = ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTO;

        // Create Mock
        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        changeSessionBsMock.addDataToChangeSession(ChangeSessionOperation.UPDATE, ServiceMasterDataUiBs.class,
                testData);
        EasyMock.expectLastCall().once();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        // test method
        serviceMasterDataFacadeBs.updateServiceMaster(testData);

        // Assertion
        EasyMock.verify(changeSessionBsMock);

    }

    /**
     * Test for delete service master.
     *
     * @throws EntityStillReferencedException
     */
    @Test
    public void testDeleteServiceMaster() throws EntityStillReferencedException {

        List<ServiceMasterChangeSessionDTO> deletedServiceMasterCsDtos =
                ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;
        List<ServiceDTO> emptyProductiveList = new ArrayList<ServiceDTO>();
        List<ServiceChangeSessionDTO> emptyChangedList = new ArrayList<ServiceChangeSessionDTO>();

        // Create Mocks
        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        changeSessionBsMock.addDataListToChangeSession(ChangeSessionOperation.DELETE, ServiceMasterDataUiBs.class,
                deletedServiceMasterCsDtos);
        EasyMock.expectLastCall().once();
        EasyMock.expect(changeSessionBsMock.getDataForAllUsers(ServiceChangeSessionDTO.class))
                .andReturn(emptyChangedList).once();
        EasyMock.expect(changeSessionBsMock.isChangeSessionOpenedForUser()).andReturn(true).anyTimes();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);

        ServiceMasterDataBs serviceMasterDataBsMock = EasyMock.createMock(ServiceMasterDataBs.class);
        EasyMock.expect(serviceMasterDataBsMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
                .andReturn(emptyProductiveList).once();
        replay(serviceMasterDataBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataBsMock);

        // test method
        serviceMasterDataFacadeBs.deleteServiceMasters(deletedServiceMasterCsDtos);

        // Assertion
        EasyMock.verify(changeSessionBsMock);
        EasyMock.verify(serviceMasterDataBsMock);
    }

    /**
     * Test for delete service master (EntityStillReferencedException).
     *
     * @throws EntityStillReferencedException
     */
    @Test(expected = EntityStillReferencedException.class)
    public void testDeleteServiceMasterUnsuccessful() throws EntityStillReferencedException {

        List<ServiceMasterChangeSessionDTO> deletedServiceMasterCsDtos =
                ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;
        List<ServiceDTO> productiveList = ServicesTestSet.ALL_REFERENCING_SERVICE_DTOS;
        List<ServiceChangeSessionDTO> changedList = ServicesTestSet.SERVICECHANGESESSIONDTO_LIST;

        // #region Create Mocks
        ServiceMasterDataBs serviceMasterDataBsMock = EasyMock.createMock(ServiceMasterDataBs.class);
        EasyMock.expect(serviceMasterDataBsMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
                .andReturn(productiveList).once();
        replay(serviceMasterDataBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataBsMock);

        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        changeSessionBsMock.addDataListToChangeSession(ChangeSessionOperation.DELETE, ServiceMasterDataUiBs.class,
                deletedServiceMasterCsDtos);
        EasyMock.expectLastCall().once();
        EasyMock.expect(changeSessionBsMock.getDataForAllUsers(ServiceChangeSessionDTO.class)).andReturn(changedList)
                .once();
        EasyMock.expect(changeSessionBsMock.isChangeSessionOpenedForUser()).andReturn(false).anyTimes();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);
        // #endregion

        // test method
        serviceMasterDataFacadeBs.deleteServiceMasters(deletedServiceMasterCsDtos);

        // Assertion
        EasyMock.verify(changeSessionBsMock);
        EasyMock.verify(serviceMasterDataBsMock);
    }

    @Test
    public void testDeleteServiceMasterWithServiceIdSameLikeDeletedServiceMasterId()
            throws EntityStillReferencedException {
        List<ServiceMasterChangeSessionDTO> deletedServiceMasterCsDtos =
                ServiceMasterTestSet.SERVICEMASTER_CHANGESESSION_DTOS;
        List<ServiceDTO> productiveList = new ArrayList<ServiceDTO>();
        List<ServiceChangeSessionDTO> changedList = ServicesTestSet.SERVICECHANGESESSIONDTO_LIST;
        changedList.get(0).getData().getService().setServiceId(101L);
        changedList.get(0).setOperation(ChangeSessionOperation.NEW);

        // #region Create Mocks
        ServiceMasterDataBs serviceMasterDataBsMock = EasyMock.createMock(ServiceMasterDataBs.class);
        EasyMock.expect(serviceMasterDataBsMock.getAllServices(null, ServiceBusinessAreaEnum.ALL, false))
                .andReturn(productiveList).once();
        replay(serviceMasterDataBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, serviceMasterDataBsMock);

        ChangeSessionBs changeSessionBsMock = EasyMock.createMock(ChangeSessionBs.class);
        changeSessionBsMock.addDataListToChangeSession(ChangeSessionOperation.DELETE, ServiceMasterDataUiBs.class,
                deletedServiceMasterCsDtos);
        EasyMock.expectLastCall().once();
        EasyMock.expect(changeSessionBsMock.getDataForAllUsers(ServiceChangeSessionDTO.class)).andReturn(changedList)
                .once();
        EasyMock.expect(changeSessionBsMock.isChangeSessionOpenedForUser()).andReturn(true).anyTimes();
        replay(changeSessionBsMock);
        mocker.setMock(serviceMasterDataFacadeBs, changeSessionBsMock);
        // #endregion

        // test method
        serviceMasterDataFacadeBs.deleteServiceMasters(deletedServiceMasterCsDtos);

        // Assertion
        EasyMock.verify(changeSessionBsMock);
        EasyMock.verify(serviceMasterDataBsMock);
    }

}
