/*+***********************************************************************
   Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

   File:         $Id: $

   FileType:      Class

   Version:      $Revision: $

 **************************************************************************/

package com.daimler.soe.services.servicemasterdata.business.service;

import static java.util.Arrays.asList;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.apache.commons.collections.CollectionUtils;
import org.easymock.Capture;
import org.easymock.EasyMock;
import org.hamcrest.Matchers;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.experimental.categories.Category;

import com.capgemini.psp.server.plain.api.annotation.RequireResource;
import com.capgemini.psp.server.test.Environment;
import com.capgemini.psp.server.test.EnvironmentType;
import com.daimler.soe.foundation.base.enums.BusinessAreaEnum;
import com.daimler.soe.foundation.base.exceptions.SoeBusinessException;
import com.daimler.soe.foundation.psp.server.test.PspMocker;
import com.daimler.soe.foundation.testdata.FoundationTestSet;
import com.daimler.soe.services.servicemasterdata.business.function.ServiceBf;
import com.daimler.soe.services.servicemasterdata.business.function.ServiceMasterDataBf;
import com.daimler.soe.services.servicemasterdata.business.transformation.ServiceMasterDataEntityTOConverter;
import com.daimler.soe.services.servicemasterdata.persistence.entities.ServiceBE;
import com.daimler.soe.services.servicemasterdata.persistence.service.ServicePs;
import com.daimler.soe.services.testdata.ServicesTestSet;
import com.daimler.soe.services.testdata.YearCodeCombinationSarTestSet;
import com.daimler.soe.techbase.testdata.DatesTestSet;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.business.service.VehicleConfigurationDTO;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.business.service.VehicleEquipmentDTO;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.business.service.VehicleProductMasterDataBs;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.business.service.VehicleTypeEnum;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.ChangeYearTestSet;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.EquipmentTestSet;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.ModelSeriesTestSet;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.ModelYearTestSet;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.SalesTypeTestSet;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.VehicleProductBuilder;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.VehicleProductMasterDataBsMock;
import com.daimler.soe.vehicleproduct.vehicleproductmasterdata.testdata.VehicleProductTestSet;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.MatchingVehicleSelectionRTO;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleConfirgurationMatchingSelectionPTO;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionDTO;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionIifBs;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionsTestSourcesEnum;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.testdata.VehicleSelectionTestSet;
import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.sdm.quasar.common.net.ClientInformation;
import com.sdm.quasar.common.net.ServerEnvironment;
import com.sdm.quasar.common.net.ServerInformation;

/**
 * Test methods for VehicleSelectionTest (Test Simulator).
 *
 * @author Capgemini
 */

@Environment(type = EnvironmentType.PLAIN, scenario = "com.daimler.soe.services.servicemasterdata")
@Category(com.daimler.soe.foundation.junit.categories.UnitTestCategory.class)
public class TestVehicleSelectionsTest {

   /** Address country code. */
   private static final String ADDRESS_COUNTRY_CODE_DE = FoundationTestSet.COUNTRY_DE;

   /** Consumer country code. */
   private static final String CONSUMER_COUNTRY_CODE_IT = FoundationTestSet.COUNTRY_IT;

   /** Productive enum to run a test with productive data. */
   private static final VehicleSelectionsTestSourcesEnum PRODUCTIVE = VehicleSelectionsTestSourcesEnum.PRODUCTIVE;

   /** The mocker. */
   @Rule
   public PspMocker mocker = new PspMocker();

   /** Contains env instance of ServerEnvironment. */
   @RequireResource
   private ServerEnvironment<ClientInformation, ServerInformation> env;

   /** Service master data. */
   private ServiceMasterDataBs serviceMasterDataBs;

   /**
    * Initialize objects and resources.
    */
   @Before
   public void setUp() {
      this.serviceMasterDataBs = new ServiceMasterDataBsBean();
      ServicesTestSet.reset();
      VehicleSelectionTestSet.reset();
      SalesTypeTestSet.reset();
   }

   /**
    * Check the result of the productive data if FIN exists. The consumer country code is expected to be null.
    * @throws SoeBusinessException the SoeBusinessException.
    */
   @Test
   public void testVehicleSelectionsProductiveDataWithFinOVinTest() throws SoeBusinessException {
      Date simulationTime = new Date();

      List<String> changeYearCodes = null;
      Set<String> equipmentCodes = new HashSet<String>();

      VehicleConfigurationDTO vehConf =
            VehicleProductBuilder.createVehicleConfigurationDTO(VehicleProductTestSet.FIN1001000000000,
                  DatesTestSet.DATE_01_01_2015_0_0_0, SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE,
                  ModelYearTestSet.MODEL_YEAR_2015_CODE, changeYearCodes, CONSUMER_COUNTRY_CODE_IT);
      VehicleEquipmentDTO vehEq = new VehicleEquipmentDTO();
      vehEq.setCode(ModelYearTestSet.MODEL_YEAR_2015_CODE);
      vehConf.getVehicleEquipments().add(vehEq);

      VehicleSelectionTestSimulationPTO rulesDTO = new VehicleSelectionTestSimulationPTO();
      rulesDTO.setVin("WD");
      rulesDTO.setSelectedSource(PRODUCTIVE);
      rulesDTO.setVinAvailable(true);
      rulesDTO.setAddressCountryCode(ADDRESS_COUNTRY_CODE_DE);
      rulesDTO.setSimulationDate(simulationTime);
      rulesDTO.setModelSeriesId(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getModelSeries());
      rulesDTO.setModelYearCode(ModelYearTestSet.MODEL_YEAR_2015_CODE);
      rulesDTO.setChangeYearCodes(null);
      rulesDTO.setConsumerCountryCode(CONSUMER_COUNTRY_CODE_IT);
      rulesDTO.setEquipmentCodes(equipmentCodes);
      rulesDTO.setLocale(FoundationTestSet.LOCALE_DE_DE);
      rulesDTO.setSalesTypeDto(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE);

      VehicleConfirgurationMatchingSelectionPTO vehicleConfiguration =
            new VehicleConfirgurationMatchingSelectionPTO();
      vehicleConfiguration.setBaumuster(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getBaumuster());
      vehicleConfiguration.setConsumerCountryCode(CONSUMER_COUNTRY_CODE_IT);
      vehicleConfiguration.setEquipmentCodes(equipmentCodes);
      vehicleConfiguration.getEquipmentCodes().add(ModelYearTestSet.MODEL_YEAR_2015_CODE);
      vehicleConfiguration.setModelSeries(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getModelSeries());
      vehicleConfiguration.setNst(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getNst());
      vehicleConfiguration.setBaumuster(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getBaumuster());

      List<MatchingVehicleSelectionRTO> matchingSelections = new ArrayList<MatchingVehicleSelectionRTO>();
      MatchingVehicleSelectionRTO matching1 = new MatchingVehicleSelectionRTO();
      matching1.setVehicleSelectionId(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_1);
      MatchingVehicleSelectionRTO matching2 = new MatchingVehicleSelectionRTO();
      matching2.setVehicleSelectionId(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_2);
      matchingSelections.add(matching1);
      matchingSelections.add(matching2);

      List<String> vehicleSelectionIds = new ArrayList<String>();
      vehicleSelectionIds.add(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_1);
      vehicleSelectionIds.add(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_2);

      List<VehicleSelectionDTO> vehicleSelectionDTOs = new ArrayList<VehicleSelectionDTO>();
      vehicleSelectionDTOs.add(VehicleSelectionTestSet.VEHICLE_SELECTION_DTO_1);
      vehicleSelectionDTOs.add(VehicleSelectionTestSet.VEHICLE_SELECTION_DTO_2);

      List<ServiceBE> serviceBEs = ServicesTestSet.ALL_SERVICE_BES;
      Set<ServiceDTO> services = new HashSet<ServiceDTO>();
      for (ServiceBE serviceBE : serviceBEs) {
         if (CollectionUtils.containsAny(serviceBE.getVehicleSelectionIds(), vehicleSelectionIds)) {
            services.add(ServiceMasterDataEntityTOConverter.convertServiceEntityToDTO(serviceBE));
         }
      }

      List<ServicePartialDTO> servicePartials =
            ServiceMasterDataEntityTOConverter.convertServiceEntitiesToPartialDTOs(serviceBEs);
      Set<ServiceAndMatchedSelectionsCDTO> serviceAndMatchedSelections =
            new HashSet<ServiceAndMatchedSelectionsCDTO>();

      Capture<List<Long>> capturedServiceIds = new Capture<List<Long>>();

      VehicleSelectionIifBs vehicleSelectionIifBsMock = EasyMock.createMock(VehicleSelectionIifBs.class);
      EasyMock.expect(vehicleSelectionIifBsMock.getMatchingVehicleSelections(vehicleConfiguration, null)).andReturn(
            matchingSelections);
      EasyMock.expect(vehicleSelectionIifBsMock.getVehicleSelectionsByVehicleSelectionIds(vehicleSelectionIds, null))
            .andReturn(vehicleSelectionDTOs);
      EasyMock.replay(vehicleSelectionIifBsMock);
      mocker.setMock(serviceMasterDataBs, vehicleSelectionIifBsMock);

      ServiceMasterDataBf serviceMasterDataBfMock = EasyMock.createMock(ServiceMasterDataBf.class);
      EasyMock.expect(
            serviceMasterDataBfMock.retrieveServicesAndMatchedSelections(vehicleSelectionDTOs, servicePartials,
                  vehicleConfiguration.getEquipmentCodes())).andReturn(serviceAndMatchedSelections);
      EasyMock.replay(serviceMasterDataBfMock);
      mocker.setMock(serviceMasterDataBs, serviceMasterDataBfMock);

      ServicePs servicePsMock = EasyMock.createMock(ServicePs.class);
      EasyMock.expect(servicePsMock.readServices(null, null, true)).andReturn(serviceBEs);
      EasyMock.expect(servicePsMock.getServicesByServiceIds(EasyMock.capture(capturedServiceIds))).andReturn(
            serviceBEs);
      EasyMock.replay(servicePsMock);
      mocker.setMock(serviceMasterDataBs, servicePsMock);

      ServiceBf serviceBfMock = EasyMock.createMock(ServiceBf.class);
      EasyMock.expect(serviceBfMock.determineVehicleTypeOfConfiguration(services)).andReturn(
            VehicleTypeEnum.CONNECT_VEHICLE);
      EasyMock.replay(serviceBfMock);
      mocker.setMock(serviceMasterDataBs, serviceBfMock);

      VehicleProductMasterDataBs vehicleProductMasterDataBs = EasyMock.createMock(VehicleProductMasterDataBs.class);
      VehicleProductMasterDataBsMock.mockFetchVehicleData(vehicleProductMasterDataBs, rulesDTO.getVin(),
            rulesDTO.getLocale(), rulesDTO.getAddressCountryCode(), vehConf);
      EasyMock.replay(vehicleProductMasterDataBs);
      mocker.setMock(serviceMasterDataBs, vehicleProductMasterDataBs);

      ServicesAndMatchedSelectionsCDTO result = serviceMasterDataBs.testVehicleSelections(rulesDTO, null, null);

      Assert.assertEquals(VehicleTypeEnum.CONNECT_VEHICLE, result.getVehicleType());
      Assert.assertThat(result.getMatchedServicesRulesEquipmentCodes(), Matchers.hasSize(0));

      Assert.assertThat(capturedServiceIds.getValue(), Matchers.hasSize(services.size()));

      EasyMock.verify(vehicleSelectionIifBsMock);
      EasyMock.verify(serviceMasterDataBfMock);
      EasyMock.verify(servicePsMock);
      EasyMock.verify(serviceBfMock);
      EasyMock.verify(vehicleProductMasterDataBs);
   }

   /**
    * Check the result of the productive data if FIN does NOT exists. The consumer country code is expected to be
    * CONSUMER_COUNTRY_CODE_IT.
    * @throws SoeBusinessException the SoeBusinessException.
    */
   @Test
   public void testVehicleSelectionsProductiveDataWithoutFinOVinTest() throws SoeBusinessException {

      List<String> changeYearCodes = Lists.newArrayList(YearCodeCombinationSarTestSet.CHANGE_YEAR_233);
      Set<String> equipmentCodes = new HashSet<String>();

      VehicleSelectionTestSimulationPTO rulesDTO = new VehicleSelectionTestSimulationPTO();
      rulesDTO.setVin(null);
      rulesDTO.setSelectedSource(PRODUCTIVE);
      rulesDTO.setVinAvailable(false);
      rulesDTO.setAddressCountryCode(ADDRESS_COUNTRY_CODE_DE);
      rulesDTO.setConsumerCountryCode(CONSUMER_COUNTRY_CODE_IT);
      rulesDTO.setSimulationDate(new Date());
      rulesDTO.setModelSeriesId(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getModelSeries());
      rulesDTO.setModelYearCode(ModelYearTestSet.MODEL_YEAR_2015_CODE);
      rulesDTO.setChangeYearCodes(changeYearCodes);
      rulesDTO.setEquipmentCodes(equipmentCodes);
      rulesDTO.setLocale(FoundationTestSet.LOCALE_DE_DE);
      rulesDTO.setSalesTypeDto(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE);

      VehicleConfirgurationMatchingSelectionPTO vehicleConfiguration =
            new VehicleConfirgurationMatchingSelectionPTO();
      rulesDTO.setProductGroup(ModelSeriesTestSet.MODEL_SERIES_DTO_205.getProductGroup());
      vehicleConfiguration.setConsumerCountryCode(CONSUMER_COUNTRY_CODE_IT);
      vehicleConfiguration.setEquipmentCodes(equipmentCodes);
      vehicleConfiguration.getEquipmentCodes().add(ModelYearTestSet.MODEL_YEAR_2015_CODE);
      vehicleConfiguration.setModelSeries(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getModelSeries());
      vehicleConfiguration.setNst(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getNst());
      vehicleConfiguration.setBaumuster(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getBaumuster());

      List<MatchingVehicleSelectionRTO> matchingSelections = new ArrayList<MatchingVehicleSelectionRTO>();
      MatchingVehicleSelectionRTO matching1 = new MatchingVehicleSelectionRTO();
      matching1.setVehicleSelectionId(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_1);
      MatchingVehicleSelectionRTO matching2 = new MatchingVehicleSelectionRTO();
      matching2.setVehicleSelectionId(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_2);
      matchingSelections.add(matching1);
      matchingSelections.add(matching2);

      List<String> vehicleSelectionIds = new ArrayList<String>();
      vehicleSelectionIds.add(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_1);
      vehicleSelectionIds.add(VehicleSelectionTestSet.VEHICLE_SELECTION_ID_2);

      List<VehicleSelectionDTO> vehicleSelectionDTOs = new ArrayList<VehicleSelectionDTO>();
      vehicleSelectionDTOs.add(VehicleSelectionTestSet.VEHICLE_SELECTION_DTO_1);
      vehicleSelectionDTOs.add(VehicleSelectionTestSet.VEHICLE_SELECTION_DTO_2);

      List<ServiceBE> serviceBEs = ServicesTestSet.ALL_SERVICE_BES;
      Set<ServiceDTO> services = new HashSet<ServiceDTO>();
      for (ServiceBE serviceBE : serviceBEs) {
         if (CollectionUtils.containsAny(serviceBE.getVehicleSelectionIds(), vehicleSelectionIds)) {
            services.add(ServiceMasterDataEntityTOConverter.convertServiceEntityToDTO(serviceBE));
         }
      }

      List<ServicePartialDTO> servicePartials =
            ServiceMasterDataEntityTOConverter.convertServiceEntitiesToPartialDTOs(serviceBEs);
      Set<ServiceAndMatchedSelectionsCDTO> serviceAndMatchedSelections =
            new HashSet<ServiceAndMatchedSelectionsCDTO>();

      Capture<List<Long>> capturedServiceIds = new Capture<List<Long>>();

      VehicleSelectionIifBs vehicleSelectionIifBsMock = EasyMock.createMock(VehicleSelectionIifBs.class);
      EasyMock.expect(vehicleSelectionIifBsMock.getMatchingVehicleSelections(vehicleConfiguration, null)).andReturn(
            matchingSelections);
      EasyMock.expect(vehicleSelectionIifBsMock.getVehicleSelectionsByVehicleSelectionIds(vehicleSelectionIds, null))
            .andReturn(vehicleSelectionDTOs);
      EasyMock.replay(vehicleSelectionIifBsMock);
      mocker.setMock(serviceMasterDataBs, vehicleSelectionIifBsMock);

      ServiceMasterDataBf serviceMasterDataBfMock = EasyMock.createMock(ServiceMasterDataBf.class);
      EasyMock.expect(
            serviceMasterDataBfMock.retrieveServicesAndMatchedSelections(vehicleSelectionDTOs, servicePartials,
                  vehicleConfiguration.getEquipmentCodes())).andReturn(serviceAndMatchedSelections);
      EasyMock.replay(serviceMasterDataBfMock);
      mocker.setMock(serviceMasterDataBs, serviceMasterDataBfMock);

      ServicePs servicePsMock = EasyMock.createMock(ServicePs.class);
      EasyMock.expect(servicePsMock.readServicesByEvaluationDateAndBusinessArea(EasyMock.anyObject(Date.class), EasyMock.anyObject(BusinessAreaEnum.class))).andReturn(serviceBEs);
      EasyMock.expect(servicePsMock.getServicesByServiceIds(EasyMock.capture(capturedServiceIds))).andReturn(
           serviceBEs);
      EasyMock.replay(servicePsMock);
      mocker.setMock(serviceMasterDataBs, servicePsMock);

     Set<Long> serviceIds = new HashSet<Long>();
      // From here its not working
      ServiceBf serviceBfMock = EasyMock.createMock(ServiceBf.class);      
      EasyMock.expect(serviceBfMock.determineVehicleTypeOfConfiguration(services)).andReturn(
            VehicleTypeEnum.CONNECT_VEHICLE);
      EasyMock.expect(serviceBfMock.getAllServicesIds(null, EasyMock.anyObject(ServiceBusinessAreaEnum.class),true)).andReturn(serviceIds);
      EasyMock.replay(serviceBfMock);
      mocker.setMock(serviceMasterDataBs, serviceBfMock);

      ServicesAndMatchedSelectionsCDTO result = serviceMasterDataBs.testVehicleSelections(rulesDTO, null, null);

      Assert.assertEquals(VehicleTypeEnum.CONNECT_VEHICLE, result.getVehicleType());
      Assert.assertThat(result.getMatchedServicesRulesEquipmentCodes(), Matchers.hasSize(0));

      Assert.assertThat(capturedServiceIds.getValue(), Matchers.hasSize(services.size()));

      EasyMock.verify(vehicleSelectionIifBsMock);
      EasyMock.verify(serviceMasterDataBfMock);
      EasyMock.verify(servicePsMock);
      EasyMock.verify(serviceBfMock);
   }

 /*  *//**
    * Check the result of the productive and change session data.
    * @throws SoeBusinessException the SoeBusinessException.
    *//*
   @Test
   public void testVehicleSelectionsChangeSessionDataTest() throws SoeBusinessException {

      VehicleSelectionTestSimulationPTO testRulesPto = new VehicleSelectionTestSimulationPTO();
      testRulesPto.setVin(null);
      testRulesPto.setSelectedSource(PRODUCTIVE);
      testRulesPto.setVinAvailable(false);
      testRulesPto.setAddressCountryCode(ADDRESS_COUNTRY_CODE_DE);
      testRulesPto.setConsumerCountryCode(CONSUMER_COUNTRY_CODE_IT);
      testRulesPto.setSimulationDate(new Date());
      testRulesPto.setModelSeriesId(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getModelSeries());
      testRulesPto.setModelYearCode(ModelYearTestSet.MODEL_YEAR_2015_CODE);
      testRulesPto.setChangeYearCodes(asList(ChangeYearTestSet.CHANGE_YEAR_050_CODE));
      testRulesPto.setEquipmentCodes(Sets.newHashSet(EquipmentTestSet.ALL_EQUIPMENT_CODES));
      testRulesPto.setLocale(FoundationTestSet.LOCALE_DE_DE);
      testRulesPto.setSalesTypeDto(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE);
      testRulesPto.setBusinessArea(ServiceBusinessAreaEnum.ALL);

      VehicleConfirgurationMatchingSelectionPTO vehicleConfiguration =
            new VehicleConfirgurationMatchingSelectionPTO();
      testRulesPto.setProductGroup(ModelSeriesTestSet.MODEL_SERIES_DTO_205.getProductGroup());
      vehicleConfiguration.setConsumerCountryCode(CONSUMER_COUNTRY_CODE_IT);
      vehicleConfiguration.setEquipmentCodes(Sets.newHashSet(EquipmentTestSet.ALL_EQUIPMENT_CODES));
      vehicleConfiguration.getEquipmentCodes().add(ChangeYearTestSet.CHANGE_YEAR_050_CODE);
      vehicleConfiguration.getEquipmentCodes().add(ModelYearTestSet.MODEL_YEAR_2015_CODE);
      vehicleConfiguration.setModelSeries(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getModelSeries());
      vehicleConfiguration.setNst(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getNst());
      vehicleConfiguration.setBaumuster(SalesTypeTestSet.SALES_TYPE_DTO_205_LIMOUSINE.getBaumuster());

      List<MatchingVehicleSelectionRTO> matchingSelections = new ArrayList<MatchingVehicleSelectionRTO>();
      List<String> vehicleSelectionIds = new ArrayList<String>();
      List<VehicleSelectionDTO> vehicleSelectionDTOs = new ArrayList<VehicleSelectionDTO>();
      List<ServicePartialDTO> servicePartials = new ArrayList<ServicePartialDTO>();
      Set<ServiceDTO> services = new HashSet<ServiceDTO>();
      Set<ServiceAndMatchedSelectionsCDTO> serviceAndMatchedSelections =
            new HashSet<ServiceAndMatchedSelectionsCDTO>();
      List<ServiceBE> serviceBEs = new ArrayList<ServiceBE>();
      List<Long> serviceIds = new ArrayList<Long>();

      VehicleSelectionIifBs vehicleSelectionIifBsMock = EasyMock.createMock(VehicleSelectionIifBs.class);
      EasyMock.expect(vehicleSelectionIifBsMock.getMatchingVehicleSelections(vehicleConfiguration, null)).andReturn(
            matchingSelections);
      EasyMock.expect(vehicleSelectionIifBsMock.getVehicleSelectionsByVehicleSelectionIds(vehicleSelectionIds, null))
            .andReturn(vehicleSelectionDTOs);
      EasyMock.replay(vehicleSelectionIifBsMock);
      mocker.setMock(serviceMasterDataBs, vehicleSelectionIifBsMock);
      
      

      ServiceMasterDataBf serviceMasterDataBfMock = EasyMock.createMock(ServiceMasterDataBf.class);
      EasyMock.expect(
            serviceMasterDataBfMock.retrieveServicesAndMatchedSelections(vehicleSelectionDTOs, servicePartials,
                  vehicleConfiguration.getEquipmentCodes())).andReturn(serviceAndMatchedSelections);
      EasyMock.replay(serviceMasterDataBfMock);
      mocker.setMock(serviceMasterDataBs, serviceMasterDataBfMock);

      ServicePs servicePsMock = EasyMock.createMock(ServicePs.class);
      EasyMock.expect(servicePsMock.readServicesByEvaluationDateAndBusinessArea(new Date(),null)).andReturn(serviceBEs);
      EasyMock.expect(servicePsMock.getServicesByServiceIds(serviceIds)).andReturn(serviceBEs);
      EasyMock.replay(servicePsMock);
      mocker.setMock(serviceMasterDataBs, servicePsMock);

      ServiceBf serviceBfMock = EasyMock.createMock(ServiceBf.class);
      EasyMock.expect(serviceBfMock.determineVehicleTypeOfConfiguration(services)).andReturn(VehicleTypeEnum.NONE);
      EasyMock.replay(serviceBfMock);
      mocker.setMock(serviceMasterDataBs, serviceBfMock);

      ServicesAndMatchedSelectionsCDTO servicesAndMatchedSelectionsDTO = new ServicesAndMatchedSelectionsCDTO();
      servicesAndMatchedSelectionsDTO.setVehicleType(VehicleTypeEnum.NONE);

      ServicesAndMatchedSelectionsCDTO result =
            serviceMasterDataBs.testVehicleSelections(testRulesPto, null, null);

      Assert.assertEquals(servicesAndMatchedSelectionsDTO.getVehicleType(), result.getVehicleType());
      Assert.assertThat(servicesAndMatchedSelectionsDTO.getMatchedServicesRulesEquipmentCodes(), Matchers.hasSize(0));
      EasyMock.verify(vehicleSelectionIifBsMock);
      EasyMock.verify(serviceMasterDataBfMock);
      EasyMock.verify(servicePsMock);
      EasyMock.verify(serviceBfMock);
   }*/
}
