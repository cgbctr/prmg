/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File:RestResponseHandler           $Id: $

    FileType:       Class

    Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.externalsystemsin.rest.base;

import java.util.LinkedHashMap;
import java.util.Properties;

import org.apache.wink.server.handlers.HandlersChain;
import org.apache.wink.server.handlers.MessageContext;
import org.apache.wink.server.handlers.ResponseHandler;

import com.daimler.soe.foundation.base.SoeSrvFoundationPaiMessageIds;
import com.daimler.soe.techbase.base.enums.LoggingContextEnum;
import com.daimler.soe.techbase.logging.LoggingManager;
import com.dcx.iap.logging.ApplicationLogger;

/**
 * Custom Response Handler implementation to add SOE specific behavior during general REST service invocation.
 * 
 * @author Capgemini
 */
public class RestResponseHandler implements ResponseHandler {

    /** The logger. */
    private static final ApplicationLogger LOGGER = ApplicationLogger.getApplicationLogger(RestResponseHandler.class
            .getCanonicalName());

    /** Calling Application. */
    private static final String CALLING_APPLICATION = "Calling Application";

    /** Response Code. */
    private static final String RESPONSE_CODE = "response-code";

    /** HTTP Status. */
    private static final String HTTP_STATUS = "http-status";

    /** ApplicationLogger instance. */
    private LoggingManager loggingManager;

    /**
     * initializing with workArea for LoggingManager instance.
     */
    private void initLoggingManager() {
        if (loggingManager == null) {
            loggingManager = new LoggingManager();
        }
        loggingManager.initWorkArea();
    }

    /** initialization. */
    @Override
    public void init(Properties properties) {
        // do nothing, since we don't need the properties
    }

    /**
     * response handler for the rest services.
     * 
     * @param paramMessageContext {@link MessageContext}
     * @param paramHandlersChain {@link HandlersChain}
     * @throws Throwable
     */
    @Override
    // CHECKSTYLE:OFF
            public
            void handleResponse(MessageContext paramMessageContext, HandlersChain paramHandlersChain) throws Throwable {
        // CHECKSTYLE:ON
        initLoggingManager();
        String callingApplication =
                loggingManager.retrieveFromWorkArea(LoggingContextEnum.CONTEXT_KEY_CALLING_APPLICATION);

        int httpStatus = paramMessageContext.getResponseStatusCode();

        LinkedHashMap<String, String> linkedHashmap = new LinkedHashMap<String, String>();
		linkedHashmap.put(RESPONSE_CODE, Integer.toString(MessageResponseCodes.SUCCESS));
        linkedHashmap.put(HTTP_STATUS, Integer.toString(httpStatus));
        linkedHashmap.put(CALLING_APPLICATION, callingApplication);        

        String message = RestUtil.generateMessageString(linkedHashmap);

        LOGGER.info(SoeSrvFoundationPaiMessageIds.DCVSERVICETRACE, message, "");
        loggingManager.clean();
        paramHandlersChain.doChain(paramMessageContext);
    }

}
