/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: RestErrorHandler          $Id: $

    FileType:       Class

    Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.externalsystemsin.rest.base;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Properties;

import javax.ws.rs.core.Response;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.wink.server.handlers.HandlersChain;
import org.apache.wink.server.handlers.MessageContext;
import org.apache.wink.server.handlers.ResponseHandler;

import com.daimler.soe.foundation.base.SoeSrvFoundationPaiMessageIds;
import com.daimler.soe.techbase.base.enums.LoggingContextEnum;
import com.daimler.soe.techbase.logging.LoggingManager;
import com.dcx.iap.logging.ApplicationLogger;

/**
 * Custom Error Handler implementation to add SOE specific behavior during general REST service invocation.
 * 
 * @author Capgemini
 */
public class RestErrorHandler implements ResponseHandler {

    /** The logger. */
    private static final ApplicationLogger LOGGER = ApplicationLogger.getApplicationLogger(RestErrorHandler.class
            .getCanonicalName());

    /** Calling Application. */
    private static final String CALLING_APPLICATION = "Calling Application";

    /** Response Code. */
    private static final String RESPONSE_CODE = "response-code";

    /** HTTP Status. */
    private static final String HTTP_STATUS = "http-status";

    /** Message. */
    private static final String MESSAGE = "message";

    /** LoggingManager. */
    private LoggingManager loggingManager;

    /** {@inheritDoc} */
    @Override
    public void init(Properties properties) {
        // we don't need the properties
    }

    /**
     * Error response handler for the rest services.
     * 
     * @param messageContext {@link MessageContext}
     * @param handlersChain {@link HandlersChain}
     * @throws Throwable
     */
    @Override
    // CHECKSTYLE:OFF
            public
            void handleResponse(MessageContext messageContext, HandlersChain handlersChain) throws Throwable {
        // CHECKSTYLE:ON
        initLoggingManager();
        String callingApplication =
                loggingManager.retrieveFromWorkArea(LoggingContextEnum.CONTEXT_KEY_CALLING_APPLICATION);
        String responseCode = loggingManager.retrieveFromWorkArea(LoggingContextEnum.CONTEXT_KEY_RESPONSE_CODE);
        int httpStatus = messageContext.getResponseStatusCode();
        String errorMsg = "";
        Object entity = messageContext.getResponseEntity();
        errorMsg = getErrorMsg(entity);

        LinkedHashMap<String, String> linkedHashmap = new LinkedHashMap<String, String>();
		linkedHashmap.put(RESPONSE_CODE, responseCode);
        linkedHashmap.put(HTTP_STATUS, Integer.toString(httpStatus));
        linkedHashmap.put(CALLING_APPLICATION, callingApplication);
        linkedHashmap.put(MESSAGE, errorMsg);

        String message = RestUtil.generateMessageString(linkedHashmap);

        LOGGER.info(SoeSrvFoundationPaiMessageIds.DCVSERVICETRACE, message, "");

        loggingManager.clean();
        handlersChain.doChain(messageContext);
    }

    /**
     * initializing with workArea for LoggingManager instance.
     */
    private void initLoggingManager() {
        if (loggingManager == null) {
            loggingManager = new LoggingManager();
        }
        loggingManager.initWorkArea();
    }

    /**
     * retrieves the error message from the entity object under Message Context.
     * 
     * @param entity link{Object}
     */
    private String getErrorMsg(Object entity) {
        String errorMsg = "";
        Response response = null;
        Object responseEntity = null;
        if (entity instanceof ErrorResponse) {
            errorMsg = getMsgFromErrorResponse(entity);
        } else if ((null != entity) && (entity instanceof Response)) {
            response = (Response) entity;
            responseEntity = response.getEntity();
            if ((null != responseEntity) && !(responseEntity instanceof ErrorResponse)
                    && !(responseEntity instanceof Response)) {
                ArrayList<?> messageList = (ArrayList<?>) responseEntity;
                if (CollectionUtils.isNotEmpty(messageList)) {
                    return ObjectUtils.toString(messageList.get(0));

                }
            }
            errorMsg = getMsgFromErrorResponse(responseEntity);
        }

        return errorMsg;
    }

    /**
     * retrieves the error message from the ErrorResponse object.
     * 
     * @param entity link{Object}
     */
    private String getMsgFromErrorResponse(Object entity) {
        String errorMsg = "";
        ErrorResponse errorResponse = null;
        if (entity instanceof ErrorResponse) {
            errorResponse = (ErrorResponse) entity;
            if (CollectionUtils.isNotEmpty(errorResponse.getMessages())) {
                errorMsg = ObjectUtils.toString(errorResponse.getMessages().get(0));
            }
        }
        return errorMsg;
    }
}
