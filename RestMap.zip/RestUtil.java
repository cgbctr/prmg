/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File:           $Id: $

    FileType:       Class

    Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.externalsystemsin.rest.base;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

/**
 * Utility class for REST service base implementation.
 * 
 * @author Capgemini
 */
public final class RestUtil {
    
    /** Application Exit. */
    private static final String APPLICATION_EXIT = "Application exit";
    
    /** Tracking Id. */
    private static final String TRACKING_ID = "tracking-id";

    /** Fin or Vin. */
    private static final String FIN_OR_VIN = "fin-or-vin";

    /** Resource Path. */
    private static final String RESOURCE_PATH = "resource-path";
    
    /** Header Information. */
    public static final Set<String> HEADER_INFORMATION = new HashSet<String>(
            Arrays.asList(APPLICATION_EXIT, TRACKING_ID, FIN_OR_VIN, RESOURCE_PATH));
    
    /** Black List of service names which are not to be logged. */
    public static final Set<String> INTERFACE_BLACK_LIST = new HashSet<String>(
            Arrays.asList("generateformattedaddress", "triggerinformofmasterdatachange", "informofcustomerdatachange"));
    
    /** HTTP method POST . */
    private static final String HTTP_METHOD_POST = "POST";
    
    /** HTTP method PUT . */
    private static final String HTTP_METHOD_PUT = "PUT";    
    
    /** HTTP method Information. */
    public static final Set<String> HTTP_METHODS_PUT_OR_POST = new HashSet<String>(
            Arrays.asList(HTTP_METHOD_POST, HTTP_METHOD_PUT));   


    /**
     * Creates instance of RestUtil.
     */
    private RestUtil() {
        // prevent instantiation.
    }

    /**
     * Returns the resources name by a given uri object.
     * 
     * @param matchedURIs
     *            the uris to be evaluated.
     * @return the requested resource.
     */
    public static String extractSubResourcePathFromUri(List<String> matchedURIs) {
        String longest = "";
        for (String uri : matchedURIs) {
            if (longest.length() < uri.length()) {
                longest = uri;
            }
        }
        return longest;
    }

    /**
     * Returns the sub resource name by a given uri object.
     * 
     * @param matchedURIs
     *            the uris to be evaluated.
     * @return the requested resource.
     */
    public static String extractSubResourceNameFromUri(List<String> matchedURIs) {

        String resourcePath = StringUtils.getCommonPrefix(matchedURIs.toArray(new String[matchedURIs.size()]));
        String subResourceResourcePath = "";

        for (String uri : matchedURIs) {
            if (subResourceResourcePath.length() < uri.length()) {
                subResourceResourcePath = uri;
            }
        }
        String subResourceName = StringUtils.difference(resourcePath, subResourceResourcePath);
        subResourceName = subResourceName.replace("/", "");
        return subResourceName;
    }

    /**
     * Extracts the version number of a given resource path.
     * 
     * @param resourcePath
     *            the path of the resource containing the version.
     * @return the version number of a given resource path.
     */
    public static String extractVersionFromResourceName(String resourcePath) {
        Pattern pattern = Pattern.compile("/v.*?/");
        Matcher matcher = pattern.matcher(resourcePath);
        String version = "";
        if (matcher.find()) {
            version = matcher.group();
        }

        version = version.replace("/", "");
        version = version.toUpperCase();
        return version;
    }

    /**
     * Builds a log string for application enter.
     * 
     * @param callingApplication
     *            the name of the application which called the REST interface.
     * @param subResourcePath
     *            the path to the called sub resource.
     * @return the application enter log string.
     */
    public static String buildApplicationEnterLog(String callingApplication, String subResourcePath) {
        StringBuilder applicationEnterBuilder = new StringBuilder("Application enter (");
        applicationEnterBuilder.append(subResourcePath).append(')');
        if (StringUtils.isNotBlank(callingApplication)) {
            applicationEnterBuilder.append(" (").append(callingApplication).append("->SOE)");
        }
        String applicationEnter = applicationEnterBuilder.toString();
        return applicationEnter;
    }

    /**
     * Constructs the message for logging purpose.
     * 
     * @param messageContents
     *            {@link Map} holds the information which is required for
     *            constructing the message.
     * @return messageString
     */
    public static String generateMessageString(Map<String, String> messageContents) {
        StringBuilder message = new StringBuilder("");

        if (null != messageContents) {
            int index = 0;
            for (Map.Entry<String, String> entry : messageContents.entrySet()) {

                if (StringUtils.isNotBlank(entry.getKey()) && StringUtils.isNotBlank(entry.getValue())) {

                    if (index > 0) {
                        message.append(", ");
                    }

                    if (HEADER_INFORMATION.contains(entry.getKey())) {
                        message.append(entry.getValue());
                    } else {
                        message.append(entry.getKey()).append(": ").append(entry.getValue());
                    }

                    index++;

                }
            }
        }

        return message.toString();
    }

    /**
     * Checks whether the service name is in the Black List.
     *
     * @param serviceName
     *            {@link String} holds the service name.
     * @return boolean.
     */
    public static boolean isBlackList(String serviceName) {

        return INTERFACE_BLACK_LIST.contains(serviceName) ? true : false;

    }
    
    /**
     * Checks whether the HTTP method is in the given List.
     *
     * @param httpMethod
     *            {@link String} holds the HTTP Method name.
     * @return boolean.
     */
    public static boolean isPutOrPost(String httpMethod) {

        return HTTP_METHODS_PUT_OR_POST.contains(httpMethod) ? true : false;

    }

}
