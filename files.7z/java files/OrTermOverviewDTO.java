/*+***********************************************************************
 Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

 File:          OrTermOverviewDTO          $Id: $

 FileType:      DTO                        Class

 Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.UUID;

import javax.faces.event.AjaxBehaviorEvent;

import com.daimler.soe.foundation.base.enums.ProductGroupEnum;

/**
 * This is the DTO object for or-terms.
 * 
 * @author Capgemini
 */
public class OrTermOverviewDTO {

    /** UUID that identifies an orTerm in the dialog. */
    private final String uiEquipmentElementId = UUID.randomUUID().toString();

    /**
     * Flag which indicates whether orTerm is negated (the equipmentCode should not match).
     */
    private boolean negation = false;

    /** MbConnect relevant equipment code that is required to match the service assignment rule with a vehicle. */
    private String equipmentCode;

    /** Equipment code's allowed product groups, i.e. "P", "T". */
    private ProductGroupEnum productGroup;

    /**
     * Creates instance of OrTerm overview DTO for the representation in the dialog.
     * 
     * @param negation of the equipmentCode
     * @param equipmentCode that is used in the service assignment rule
     * @param productGroup of the equipmentCode
     */
    public OrTermOverviewDTO(boolean negation, String equipmentCode, ProductGroupEnum productGroup) {
        this.negation = negation;
        this.equipmentCode = equipmentCode;
        this.productGroup = productGroup;
    }

    /**
     * Get the id of the orTerm. This id is used to delete an orTerm from the andTerm.
     * 
     * @return uiEquipmentElementId
     */
    public String getUiEquipmentElementId() {
        return uiEquipmentElementId;
    }

    /**
     * Get the {@link #negation}.
     * 
     * @return {@link #negation}
     */
    public Boolean getNegation() {
        return negation;
    }

    /**
     * Change the negation of the orTerm. This method is required to change the negation from the SAR dialog.
     * 
     * @param event that is required because this method is called with an ajax call
     */
    public void changeNegation(AjaxBehaviorEvent event) {
        negation = !negation;
    }

    /**
     * Set the negation of the orTerm.
     * 
     * @param negation true if the orTerm should be negated (equipmentCode should match), false if the equipmentCode
     *        should not match
     */
    public void setNegation(Boolean negation) {
        this.negation = negation;
    }

    /**
     * Get the {@link #equipmentCode}.
     * 
     * @return equipmentCode
     */
    public String getEquipmentCode() {
        return equipmentCode;
    }

    /**
     * Set the {@link #equipmentCode}.
     * 
     * @param equipmentCode that should match the service assignment rule
     */
    public void setEquipmentCode(String equipmentCode) {
        this.equipmentCode = equipmentCode;
    }

    /**
     * Get product group of the equipment.
     * 
     * @return productGroup
     */
    public ProductGroupEnum getProductGroup() {
        return productGroup;
    }

    /**
     * Set product group of the equipment.
     * 
     * @param productGroup of the equipment.
     */
    public void setProductGroup(ProductGroupEnum productGroup) {
        this.productGroup = productGroup;
    }

}
