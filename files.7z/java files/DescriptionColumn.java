/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: package-info          $Id: $

    FileType:       Class

    Version:        $Revision: $

 **************************************************************************/

package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.LocaleUtils;

import com.daimler.soe.foundation.messages.MessageHelper;
import com.daimler.soe.techbase.dtos.NameI18NDTO;

/**
 * Represents the column "Description / Services" of the service assignment rules table.
 * 
 * @author Capgemini
 */
public class DescriptionColumn {

    private static final String BRACKET_OPEN = "(";

    private static final String BRACKET_CLOSED = ")";

    private static final String TAG_BOLD_OPEN = "<b>";

    private static final String TAG_BOLD_CLOSED = "</b>";

    private static final String TAG_BR = "<br/>";

    private static final String DESCRIPTION_KEY = "GENERAL.description";

    /** Contains i18n values. */
    private final Map<String, NameI18NDTO> nameTexts = new HashMap<String, NameI18NDTO>();

    private final String description;

    private final String[] availableLocales;

    DescriptionColumn(String[] availableLocales, String description) {
        this.description = StringUtils.trimToEmpty(description);
        this.availableLocales = availableLocales;

        build();
    }

    private void build() {
        for (int i = 0; i < availableLocales.length; i++) {
            String locale = availableLocales[i];
            StringBuilder textInCol = new StringBuilder();
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(MessageHelper.getI18NText(DESCRIPTION_KEY, LocaleUtils.toLocale(locale)));
            textInCol.append(TAG_BOLD_CLOSED);
            textInCol.append(TAG_BR);
            textInCol.append(description);
            textInCol.append(TAG_BR);
            textInCol.append(TAG_BR);
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(TAG_BOLD_CLOSED);
            textInCol.append(TAG_BR);

            textInCol.append(BRACKET_OPEN);
            textInCol.append(BRACKET_CLOSED);
            textInCol.append(TAG_BR);

            nameTexts.put(locale, new NameI18NDTO(locale, textInCol.toString()));
        }
    }

    /**
     * Gets the nameTexts.
     * 
     * @return nameTexts
     */
    public Map<String, NameI18NDTO> getNameTexts() {
        return nameTexts;
    }

    /**
     * Gets the description.
     * 
     * @return description
     */
    public String getDescription() {
        return description;
    }
}
