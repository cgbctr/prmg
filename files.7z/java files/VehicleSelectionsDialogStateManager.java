/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: VehicleSelectionsDialogStateManager          $Id: $

    FileType: Class

    Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import com.daimler.soe.foundation.data.AbstractOverviewDialogStateManager;
import com.daimler.soe.foundation.data.DialogModeService;
import com.sdm.quasar.common.DisposeException;

/**
 * This dialog is used to manage the service assignment rules.
 * 
 * @author Capgemini
 */
public class VehicleSelectionsDialogStateManager extends AbstractOverviewDialogStateManager {

    @Override
    protected void init() {
        setDialogMode(getComponentControl().findService(DialogModeService.class).getDialogMode());
    }

    @Override
    protected void dispose() throws DisposeException {
        // do nothing
    }
}
