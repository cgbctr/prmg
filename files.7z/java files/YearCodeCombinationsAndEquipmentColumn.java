/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: package-info          $Id: $

    FileType:       Class

    Version:        $Revision: $

 **************************************************************************/

package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.LocaleUtils;

import com.daimler.soe.foundation.messages.MessageHelper;
import com.daimler.soe.techbase.dtos.NameI18NDTO;
import com.daimler.soe.vehicleproduct.data.comparator.YearCodeCombinationDTOComparator;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.AndTermDTO;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.YearCodeCombinationDTO;

/**
 * Represents the column "Year code combinations / Equipment" of the service assignment rules table.
 * 
 * @author Capgemini
 */
public class YearCodeCombinationsAndEquipmentColumn {

    private static final String DOTS_STRING = "...";

    private static final String SQUARE_OPEN = "[";

    private static final String SQUARE_CLOSED = "]";

    private static final String BLANK = " ";

    private static final String PLUS = "+";

    private static final String BRACKET_OPEN = "(";

    private static final String BRACKET_CLOSED = ")";

    private static final String TAG_BOLD_OPEN = "<b>";

    private static final String TAG_BOLD_CLOSED = "</b>";

    private static final String TAG_BR = "<br/>";

    private static final String MODEL_YEAR_CHANGE_YEAR_KEY = "SOE_VehicleSelectionsDialog.modelyearchangeyear";

    private static final String AND_TERM = "GENERAL.andTerm";

    private static final String OR_TERM = "GENERAL.orTerm";

    private static final String EQUIPMENT_CODES_KEY = "GENERAL.equipmentcodes";

    /** Contains i18n values. */
    private final Map<String, NameI18NDTO> nameTexts = new HashMap<String, NameI18NDTO>();

    private List<YearCodeCombinationDTO> yearCodeCombinations;

    private List<AndTermDTO> andTermDtoList;

    private final String[] availableLocales;

    private final int maxElemToDisplay;

    YearCodeCombinationsAndEquipmentColumn(String[] availableLocales,
            Collection<YearCodeCombinationDTO> yearCodeCombinations,
            List<AndTermDTO> andTermDtoList, int maxElemToDisplay) {

        this.maxElemToDisplay = maxElemToDisplay;

        if (yearCodeCombinations == null) {
            this.yearCodeCombinations = new ArrayList<YearCodeCombinationDTO>();
        } else {
            this.yearCodeCombinations = new ArrayList<YearCodeCombinationDTO>(yearCodeCombinations);
        }
/*        if (andTermDtoList == null) {
            this.andTermDtoList = new ArrayList<AndTermDTO>();
        } else {
            this.andTermDtoList = andTermDtoList;
        }*/
        this.availableLocales = availableLocales;
        Collections.sort(this.yearCodeCombinations, new YearCodeCombinationDTOComparator(Boolean.TRUE));
        build();
    }

    private void build() {
        for (int i = 0; i < availableLocales.length; i++) {
            final String locale = availableLocales[i];
            StringBuilder textInCol = new StringBuilder();
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(MessageHelper.getI18NText(MODEL_YEAR_CHANGE_YEAR_KEY, LocaleUtils.toLocale(locale)));
            textInCol.append(TAG_BOLD_CLOSED);
            textInCol.append(TAG_BR);
            int displayed = 0;
            for (YearCodeCombinationDTO yearCodeCombination : yearCodeCombinations) {
                if (displayed < maxElemToDisplay) {
                    textInCol.append(yearCodeCombination.getModelYearCode());
                    if (!StringUtils.isEmpty(yearCodeCombination.getChangeYearCode())) {
                        textInCol.append(BLANK);
                        textInCol.append(PLUS);
                        textInCol.append(BLANK);
                        textInCol.append(yearCodeCombination.getChangeYearCode());
                    }
                    textInCol.append(TAG_BR);
                    displayed++;
                } else {
                    dots(textInCol);
                }
            }
/*            textInCol.append(TAG_BR);
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(MessageHelper.getI18NText(EQUIPMENT_CODES_KEY, LocaleUtils.toLocale(locale)));
            textInCol.append(TAG_BOLD_CLOSED);
            textInCol.append(TAG_BR);

            int start = textInCol.length();
            for (AndTermDTO andTerm : andTermDtoList) {
                if (CollectionUtils.isEmpty(andTerm.getOrTerms())) {
                    continue;
                }
                if (textInCol.length() != start) {
                    textInCol.append(BLANK);
                    textInCol.append(MessageHelper.getI18NText(AND_TERM, LocaleUtils.toLocale(locale)));
                    textInCol.append(TAG_BR);
                }
                textInCol.append(BRACKET_OPEN);
                textInCol.append(StringUtils.join(
                        andTerm.getOrTerms(),
                        new StringBuilder().append(BLANK)
                                .append(MessageHelper.getI18NText(OR_TERM, LocaleUtils.toLocale(locale))).append(BLANK)
                                .toString()));
                textInCol.append(BRACKET_CLOSED);
                textInCol.append(BLANK);
            }*/
            nameTexts.put(locale, new NameI18NDTO(locale, textInCol.toString()));
        }

    }

    /**
     * Gets the nameTexts.
     * 
     * @return nameTexts
     */
    public Map<String, NameI18NDTO> getNameTexts() {
        return nameTexts;
    }

    private void dots(StringBuilder textInCol) {
        if (!textInCol.toString().endsWith(TAG_BOLD_CLOSED)) {
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(SQUARE_OPEN);
            textInCol.append(DOTS_STRING);
            textInCol.append(SQUARE_CLOSED);
            textInCol.append(TAG_BOLD_CLOSED);
        }
    }

}
