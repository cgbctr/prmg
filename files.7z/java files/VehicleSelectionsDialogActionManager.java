/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: package-info          $Id: $

    FileType: Package information file      Class

    Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import org.apache.commons.lang3.LocaleUtils;

import com.capgemini.psp.server.common.messages.Message;
import com.capgemini.psp.server.common.messages.MessageType;
import com.capgemini.psp.server.common.messages.impl.DefaultMessage;
import com.daimler.soe.changesession.services.business.service.VehicleSelectionChangeSessionDTO;
import com.daimler.soe.dialogfacade.vehicleproduct.business.service.VehicleProductFacadeBs;
import com.daimler.soe.foundation.authorizationsupport.base.ResourceConstants;
import com.daimler.soe.foundation.base.DetailDialogModeEnum;
import com.daimler.soe.foundation.base.MessageIds;
import com.daimler.soe.foundation.changesession.AbstractChangeSessionDTO;
import com.daimler.soe.foundation.creation.api.DialogCreationService;
import com.daimler.soe.foundation.data.AbstractChangeSessionDialogActionManager;
import com.daimler.soe.foundation.data.AbstractOverviewDataManager;
import com.daimler.soe.foundation.data.UIListElement;
import com.daimler.soe.foundation.data.UIListElementI18N;
import com.daimler.soe.foundation.messages.ConfirmationHandler;
import com.daimler.soe.foundation.messages.MessageService;
import com.daimler.soe.foundation.utilities.ErrorPopupHelper;
import com.daimler.soe.foundation.utilities.ServiceLocatorFactory;
import com.daimler.soe.techbase.util.AlphaNumericStringHelper;
import com.daimler.soe.vehicleproduct.vehicleselectionsdetail.api.DisplayDetailVehicleSelectionService;
import com.sdm.quasar.client.core.dialog.DeactivationCallback;
import com.sdm.quasar.component.SubComponentControl;

/**
 * The VehicleSelectionsDialogActionManager.
 * 
 * @author Capgemini
 */
public class VehicleSelectionsDialogActionManager extends AbstractChangeSessionDialogActionManager implements
        ConfirmationHandler {

    private VehicleSelectionsDialogDataManager dataManager;

    /**
     * sorting ascending/descending.
     */
    private boolean sortVehicleSelectionsIdAsc = true;

    /**
     * sorting ascending/descending.
     */
    private boolean sortDescriptionAndServicesAsc = true;

    /**
     * sorting ascending/descending.
     */
    private boolean sortByModelSeriesAsc = true;

    /**
     * sorting ascending/descending.
     */
    private boolean sortByConsumerCountry = true;

    /**
     * sorting ascending/descending.
     */
    private boolean sortByYearCodeCombinationsEquipmentsAsc = true;

    @Override
    public void init() {
        dataManager = getComponentControl().requireFeature(VehicleSelectionsDialogDataManager.class);
    }

    @Override
    public void dispose() {
        // do nothing
    }

    @Override
    protected void prepare() {
        populateVehicleSelectionsList();
    }

    /**
     * Method to be called on add button click.
     */
    public void openAddDialog() {
        openDetailDialog(dataManager.getVehicleSelectionForAdd(), DetailDialogModeEnum.ADD);
    }

    /**
     * open the edit Dialog for the selected service assignment rule.
     */
    public void edit() {
        openDetailDialog(dataManager.getVehicleSelectionChangeSession(), DetailDialogModeEnum.EDIT);
    }

    /**
     * open the edit Dialog for the selected service assignment rule.
     */
    public void view() {
        openDetailDialog(dataManager.getVehicleSelectionChangeSession(), DetailDialogModeEnum.VIEW);
    }

    private void openDetailDialog(VehicleSelectionChangeSessionDTO dto, DetailDialogModeEnum dialogMode) {
        try {
            DialogCreationService dialogCreationService =
                    getComponentControl().findService(DialogCreationService.class);

            SubComponentControl subCompControl =
                    dialogCreationService.openDialog(
                            ResourceConstants.DlgServicesConstants.VEHICLE_SELECTIONS_DETAIL_DIALOG,
                            new DeactivationCallback() {
                                @Override
                                public void deactivated() {
                                    // This is called when the newly created dialog is
                                    // deactivated.
                                    // Here you can call a service of the dialog and get
                                    // some return value
                                    // You do not have to use a DeactivationCallback if you
                                    // don't
                                    // need a return value.
                                    DialogCreationService dialogCreationService =
                                            getComponentControl().findService(DialogCreationService.class);
                                    dialogCreationService
                                            .setActiveSubDialog(ResourceConstants.DlgServicesConstants.SERV_ASS_RULES_DIALOG);
                                    populateVehicleSelectionsList();
                                }
                            });

            DisplayDetailVehicleSelectionService displayVehicleSelectionService =
                    subCompControl.getService(DisplayDetailVehicleSelectionService.class);

            VehicleProductFacadeBs vehicleProductFacade =
                    ServiceLocatorFactory.getServiceLocator().getService(VehicleProductFacadeBs.class);

            displayVehicleSelectionService.displayDetailVehicleSelection(dto,
                    vehicleProductFacade.getAllModelSeries(false), dialogMode);

        } catch (RuntimeException thrown) {
            ErrorPopupHelper.displayError(getComponentControl(), thrown);
        }
    }

    /**
     * Method to be called on delete button click.
     */
    public void delete() {
        if (dataManager.validateDelete()) {
            Message msg = new DefaultMessage(MessageIds.MSG_20007, MessageType.WARNING);
            getComponentControl().findService(MessageService.class).confirmModalMessage(msg, this);
        } else {
            Message msg = new DefaultMessage(MessageIds.MSG_10002, MessageType.INFO);
            getComponentControl().findService(MessageService.class).displayModalMessage(msg);
        }

    }

    /**
     * Method to populate the list of service assignment rules.
     */
    private void populateVehicleSelectionsList() {
        VehicleProductFacadeBs vehicleProductFacadeBs =
                ServiceLocatorFactory.getServiceLocator().getService(VehicleProductFacadeBs.class);
        dataManager.populateVehicleSelectionsList(vehicleProductFacadeBs.getVehicleSelectionsOverview());

        // sort the data and reset the sorting to ascending, because in this case it is not triggered by the user and
        // we
        // don't want the sort to toggle
        sortByVehicleSelectionId();
        sortVehicleSelectionsIdAsc = true;
    }

    @Override
    public void confirm(boolean confirmation) {
        if (confirmation) {
            try {

                VehicleProductFacadeBs masterDataBs =
                        ServiceLocatorFactory.getServiceLocator().getService(VehicleProductFacadeBs.class);
                List<VehicleSelectionChangeSessionDTO> deletedVehicleSelections =
                        dataManager.getVehicleSelectionsListForDeletion();
                masterDataBs.deleteVehicleSelections(deletedVehicleSelections);

                populateVehicleSelectionsList();

            } catch (RuntimeException thrown) {
                ErrorPopupHelper.displayError(getComponentControl(), thrown);
            }
        }
    }

    /**
     * Sort the data table by vehicle selection id.
     */
    public void sortByVehicleSelectionId() {
        try {
            if (sortVehicleSelectionsIdAsc) {
                Collections.sort(dataManager.getDataList(),
                        new Comparator<UIListElementI18N<VehicleSelectionDataTableElement>>() {

                            @Override
                            public int compare(UIListElementI18N<VehicleSelectionDataTableElement> object1,
                                    UIListElementI18N<VehicleSelectionDataTableElement> object2) {

                                return AlphaNumericStringHelper.compare(
                                        object1.getContent().getData().getBusinessKey(), object2.getContent().getData()
                                                .getBusinessKey(), null, true);

                            }
                        });
            } else {
                Collections.sort(dataManager.getDataList(),
                        new Comparator<UIListElementI18N<VehicleSelectionDataTableElement>>() {

                            @Override
                            public int compare(UIListElementI18N<VehicleSelectionDataTableElement> object1,
                                    UIListElementI18N<VehicleSelectionDataTableElement> object2) {
                                return AlphaNumericStringHelper.compare(
                                        object1.getContent().getData().getBusinessKey(), object2.getContent().getData()
                                                .getBusinessKey(), null, false);
                            }
                        });
            }
            sortVehicleSelectionsIdAsc = !sortVehicleSelectionsIdAsc;
        } catch (RuntimeException thrown) {
            ErrorPopupHelper.displayError(getComponentControl(), thrown);
        }
    }

    /**
     * Sort the data table by description and services.
     */
    public void sortDescription() {
        try {

            Collections.sort(dataManager.getDataList(),
                    new Comparator<UIListElementI18N<VehicleSelectionDataTableElement>>() {

                        @Override
                        public int compare(UIListElementI18N<VehicleSelectionDataTableElement> object1,
                                UIListElementI18N<VehicleSelectionDataTableElement> object2) {

                            String currentLanguage = dataManager.getCurrentLanguage();

                            return AlphaNumericStringHelper.compare(object1.getContent().getDescription()
                                    .getI18NTexts().get(currentLanguage), object2.getContent().getDescription()
                                    .getI18NTexts().get(currentLanguage), LocaleUtils.toLocale(currentLanguage),
                                    sortDescriptionAndServicesAsc);
                        }
                    });

            sortDescriptionAndServicesAsc = !sortDescriptionAndServicesAsc;
        } catch (RuntimeException thrown) {
            ErrorPopupHelper.displayError(getComponentControl(), thrown);
        }
    }

    /**
     * Sort the data table by model series.
     */
    public void sortByModelSeries() {
        try {

            Collections.sort(dataManager.getDataList(),
                    new Comparator<UIListElementI18N<VehicleSelectionDataTableElement>>() {

                        @Override
                        public int compare(UIListElementI18N<VehicleSelectionDataTableElement> object1,
                                UIListElementI18N<VehicleSelectionDataTableElement> object2) {

                            String currentLanguage = dataManager.getCurrentLanguage();

                            return AlphaNumericStringHelper.compare(object1.getContent().getModelSeries()
                                    .getI18NTexts().get(currentLanguage), object2.getContent().getModelSeries()
                                    .getI18NTexts().get(currentLanguage), LocaleUtils.toLocale(currentLanguage),
                                    sortByModelSeriesAsc);
                        }
                    });

            sortByModelSeriesAsc = !sortByModelSeriesAsc;
        } catch (RuntimeException thrown) {
            ErrorPopupHelper.displayError(getComponentControl(), thrown);
        }
    }

    /**
     * Sort by consumer countries.
     */
    public void sortByConsumerCountries() {
        try {

            Collections.sort(dataManager.getDataList(),
                    new Comparator<UIListElementI18N<VehicleSelectionDataTableElement>>() {

                        @Override
                        public int compare(UIListElementI18N<VehicleSelectionDataTableElement> object1,
                                UIListElementI18N<VehicleSelectionDataTableElement> object2) {

                            String currentLanguage = dataManager.getCurrentLanguage();

                            return AlphaNumericStringHelper.compare(object1.getContent().getConsumerCountries()
                                    .getI18NTexts().get(currentLanguage), object2.getContent().getConsumerCountries()
                                    .getI18NTexts().get(currentLanguage), LocaleUtils.toLocale(currentLanguage),
                                    sortByConsumerCountry);
                        }
                    });

            sortByConsumerCountry = !sortByConsumerCountry;
        } catch (RuntimeException thrown) {
            ErrorPopupHelper.displayError(getComponentControl(), thrown);
        }
    }

    /**
     * Sort the data table by model year equipments.
     */
    public void sortByYearCodeCombinationsEquipments() {
        try {

            Collections.sort(dataManager.getDataList(),
                    new Comparator<UIListElementI18N<VehicleSelectionDataTableElement>>() {

                        @Override
                        public int compare(UIListElementI18N<VehicleSelectionDataTableElement> object1,
                                UIListElementI18N<VehicleSelectionDataTableElement> object2) {

                            String currentLanguage = dataManager.getCurrentLanguage();

                            return AlphaNumericStringHelper.compare(
                                    object1.getContent().getYearCodeCombinationsAndEquipment().getI18NTexts()
                                            .get(currentLanguage),
                                    object2.getContent().getYearCodeCombinationsAndEquipment().getI18NTexts()
                                            .get(currentLanguage), LocaleUtils.toLocale(currentLanguage),
                                    sortByYearCodeCombinationsEquipmentsAsc);
                        }
                    });

            sortByYearCodeCombinationsEquipmentsAsc = !sortByYearCodeCombinationsEquipmentsAsc;
        } catch (RuntimeException thrown) {
            ErrorPopupHelper.displayError(getComponentControl(), thrown);
        }
    }

    @Override
    protected AbstractOverviewDataManager<? extends UIListElement<? extends AbstractChangeSessionDTO<?>>>
            getDataManager() {
        return dataManager;
    }

}
