/*+***********************************************************************
 Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

 File:          AndTermOverviewDTO         $Id: $

 FileType:      DTO                         Class

 Version:       $Revision: $

 **************************************************************************/
package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * This is the overview DTO object for and terms.
 * 
 * @author Capgemini
 */
public class AndTermOverviewDTO {

    /** UUID that identifies the andTerm in the dialog. */
    private final String listId = UUID.randomUUID().toString();

    /** List with {@link #OrTermOverviewDTO}s that belongs to the andTerm. */
    private List<OrTermOverviewDTO> orTermOverviewDtoList = new ArrayList<OrTermOverviewDTO>();

    /**
     * This id is used to identify the andTerm in the dialog. We need this id when we want to and an orTerm to the
     * andTerm in the dialog.
     * 
     * @return listId UUID of the andTermOverviewDTO
     */
    public String getListId() {
        return listId;
    }

    /**
     * Get the list with {@link #OrTermOverviewDTO}s that belongs to the andTerm.
     * 
     * @return orTermOverviewDtoList with {@link #OrTermOverviewDTO}s
     */
    public List<OrTermOverviewDTO> getOrTermOverviewDtoList() {
        return orTermOverviewDtoList;
    }

    /**
     * Set the list with {@link #OrTermOverviewDTO}s that belongs to the andTerm.
     * 
     * @param andTermOverviewDtoList with {@link #OrTermOverviewDTO}s
     */
    public void setOrTermOverviewDtoList(List<OrTermOverviewDTO> andTermOverviewDtoList) {
        this.orTermOverviewDtoList = andTermOverviewDtoList;
    }

    /**
     * Add an orTerm to the andTerm. This function is called from the dialog.
     * 
     * @param orEquipment {@link #OrTermOverviewDTO}
     */
    public void addOrTermOverviewDto(OrTermOverviewDTO orEquipment) {
        orTermOverviewDtoList.add(orEquipment);
    }
}
