/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: package-info          $Id: $

    FileType:       Class

    Version:        $Revision: $

 **************************************************************************/

package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.collections.keyvalue.MultiKey;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.LocaleUtils;

import com.daimler.soe.foundation.messages.MessageHelper;
import com.daimler.soe.mbconnectcountries.mbconnectcountries.business.service.MBcCountryDTO;
import com.daimler.soe.techbase.dtos.NameI18NDTO;
import com.daimler.soe.vehicleproduct.data.comparator.ConsumerCountryByNameComparator;

/**
 * Represents the column "Consumer Countries" of the service assignment rules table.
 * 
 * @author Capgemini
 */
public class ConsumerCountriesColumn {

    private static final String DOTS_STRING = "...";

    private static final String SQUARE_OPEN = "[";

    private static final String SQUARE_CLOSED = "]";

    private static final String BRACKET_OPEN = "(";

    private static final String BRACKET_CLOSED = ")";

    private static final String BLANK = " ";

    private static final String TAG_BR = "<br/>";

    private static final String TAG_BOLD_OPEN = "<b>";

    private static final String TAG_BOLD_CLOSED = "</b>";

    private static final String CONSUMER_COUNTRY_KEY = "GENERAL.availablein";

    private static final String ALL_COUNTRIES_AVAILABLE = "SOE_VehicleSelectionsDialog.allcountriesavailable";

    /** Contains i18n values. */
    private final Map<String, NameI18NDTO> nameTexts = new HashMap<String, NameI18NDTO>();

    private List<MBcCountryDTO> consumerCountries;

    private final String[] availableLocales;

    private final int maxElemToDisplay;

    ConsumerCountriesColumn(String[] availableLocales, List<String> arrayList, int maxElemToDisplay, List<MBcCountryDTO> mbCountries) {

        this.maxElemToDisplay = maxElemToDisplay;

        if (arrayList == null) {
            this.consumerCountries = new ArrayList<MBcCountryDTO>();
        } else {
            this.consumerCountries = convertCountries(arrayList, mbCountries);
        }
        this.availableLocales = availableLocales;
        build();
    }

    private void build() {

        Map<MultiKey, String> consumerCountriesMap = new HashMap<MultiKey, String>();
        for (MBcCountryDTO consumerCountry : consumerCountries) {
            fillMap(consumerCountriesMap, consumerCountry.getNameTexts().entrySet(), consumerCountry.getId());
        }
        for (int i = 0; i < availableLocales.length; i++) {
            final String locale = availableLocales[i];
            StringBuilder textInCol = new StringBuilder();
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(MessageHelper.getI18NText(CONSUMER_COUNTRY_KEY, LocaleUtils.toLocale(locale)));
            textInCol.append(':');
            textInCol.append(TAG_BOLD_CLOSED);
            textInCol.append(TAG_BR);
            Collections.sort(this.consumerCountries, new ConsumerCountryByNameComparator(locale, Boolean.TRUE));
            int displayed = 0;

            for (MBcCountryDTO consumerCountryDto : consumerCountries) {
                if (displayed < maxElemToDisplay) {
                    MultiKey key = new MultiKey(consumerCountryDto.getId(), locale);
                    if (!StringUtils.isEmpty(consumerCountriesMap.get(key))) {
                        textInCol.append(consumerCountriesMap.get(key));
                        textInCol.append(BLANK);
                    }
                    textInCol.append(BRACKET_OPEN);
                    textInCol.append(consumerCountryDto.getCountryCode());
                    textInCol.append(BRACKET_CLOSED);
                    textInCol.append(TAG_BR);
                    displayed++;
                } else {
                    dots(textInCol);
                }
            }
            if (consumerCountries.isEmpty()) {
                textInCol.append(MessageHelper.getI18NText(ALL_COUNTRIES_AVAILABLE, LocaleUtils.toLocale(locale)));
                nameTexts.put(locale, new NameI18NDTO(locale, textInCol.toString()));
            }
            nameTexts.put(locale, new NameI18NDTO(locale, textInCol.toString()));
        }
    }

    /**
     * Gets the nameTexts.
     * 
     * @return nameTexts
     */
    public Map<String, NameI18NDTO> getNameTexts() {
        return nameTexts;
    }

    private void fillMap(Map<MultiKey, String> map, Set<Entry<String, NameI18NDTO>> entySet, Long identifier) {
        for (Entry<String, NameI18NDTO> entrySet : entySet) {
            if (entrySet.getValue() != null) {
                String serviceName = StringUtils.trimToEmpty(entrySet.getValue().getName());
                MultiKey key = new MultiKey(identifier, entrySet.getKey());
                map.put(key, serviceName);
            }
        }
    }

    private void dots(StringBuilder textInCol) {
        if (!textInCol.toString().endsWith(TAG_BOLD_CLOSED)) {
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(SQUARE_OPEN);
            textInCol.append(DOTS_STRING);
            textInCol.append(SQUARE_CLOSED);
            textInCol.append(TAG_BOLD_CLOSED);
        }
    }

    private List<MBcCountryDTO> convertCountries(List<String> consumerCountryCodes, List<MBcCountryDTO> mbCountries) {
      
        List<MBcCountryDTO> result = new ArrayList<MBcCountryDTO>();
        for (MBcCountryDTO country : mbCountries) {
            if (consumerCountryCodes.contains(country.getCountryCode())) {
                result.add(country);
            }
        }
        return result;
    }

}
