/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: package-info          $Id: $

    FileType: Package information file      Class

    Version:        $Revision: $

 **************************************************************************/
/**
 * This package contains the interface of the creation service.
 */
package com.daimler.soe.vehicleproduct.vehicleselections.impl;

