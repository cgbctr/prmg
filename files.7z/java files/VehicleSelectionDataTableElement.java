/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: package-info          $Id: $

    FileType:       Class

    Version:        $Revision: $

 **************************************************************************/

package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

import com.daimler.soe.changesession.services.business.service.VehicleSelectionChangeSessionDTO;
import com.daimler.soe.foundation.data.UIListElementI18N;
import com.daimler.soe.mbconnectcountries.mbconnectcountries.business.service.MBcCountryDTO;

/**
 * Represents the row to display in the service assignment rules page.
 *
 * @author Capgemini
 */
public class VehicleSelectionDataTableElement extends VehicleSelectionChangeSessionDTO {

    private static final long serialVersionUID = -7463952709290821390L;

    /** The column Rule id. */
    private final String businessKey;

    /**
     * The column "Services / Validity".
     */
    private final UIListElementI18N<DescriptionColumn> description;

    /**
     * The column "Model Series".
     */
    private final UIListElementI18N<ModelSeriesColumn> modelSeries;

    /**
     * The column "Year code combinations / Equipment".
     */
    private final UIListElementI18N<YearCodeCombinationsAndEquipmentColumn> yearCodeCombinationsAndEquipment;
    
    /**
     * The column Equipment".
     */
    private final UIListElementI18N<EquipmentColumn> equipment;
    
    /**
     * The column SalesTypeColumn".
     */
    private final UIListElementI18N<SalesTypeColumn> salesType;

    /**
     * The column "Consumer Countries".
     */
    private final UIListElementI18N<ConsumerCountriesColumn> consumerCountries;

    /**
     * The content as DTO.
     */
    private VehicleSelectionChangeSessionDTO vehicleSelectionChangeSessionDTO;


    /**
     * Object constructor.
     *
     * @param availableLocales The list of all available locales
     * @param vehicleSelectionChangeSessionDTO the vehicle selection
     * @param maxElemToDisplay the max number of element to be displayed for each cell
     * @param mbCountries all MB Connect countries
     */
    public VehicleSelectionDataTableElement(String[] availableLocales,
            VehicleSelectionChangeSessionDTO vehicleSelectionChangeSessionDTO, int maxElemToDisplay, List<MBcCountryDTO> mbCountries) {
        super(vehicleSelectionChangeSessionDTO.getData());
        this.setChangedInSession(vehicleSelectionChangeSessionDTO.getChangedInSession());
        this.setChangeSessionDataId(vehicleSelectionChangeSessionDTO.getChangeSessionDataId());
        this.setOperation(vehicleSelectionChangeSessionDTO.getOperation());
        this.businessKey = vehicleSelectionChangeSessionDTO.getData().getBusinessKey();

        DescriptionColumn descriptionColumn =
                new DescriptionColumn(availableLocales, vehicleSelectionChangeSessionDTO.getData().getDescription());

        this.description =
                new UIListElementI18N<DescriptionColumn>(descriptionColumn, descriptionColumn.getNameTexts().values());

        ModelSeriesColumn modelSeriesColumn = new ModelSeriesColumn(availableLocales, vehicleSelectionChangeSessionDTO);

        this.modelSeries =
                new UIListElementI18N<ModelSeriesColumn>(modelSeriesColumn, modelSeriesColumn.getNameTexts().values());
        
        SalesTypeColumn salesTypeColumn = new SalesTypeColumn(availableLocales, vehicleSelectionChangeSessionDTO);
        
        this.salesType =
                new UIListElementI18N<SalesTypeColumn>(salesTypeColumn, salesTypeColumn.getNameTexts().values());

        YearCodeCombinationsAndEquipmentColumn modelYearsAndEquipmentColumn =
                new YearCodeCombinationsAndEquipmentColumn(availableLocales, vehicleSelectionChangeSessionDTO.getData()
                        .getYearCodeCombination(), vehicleSelectionChangeSessionDTO.getData().getAndTerms(),
                        maxElemToDisplay);

        this.yearCodeCombinationsAndEquipment =
                new UIListElementI18N<YearCodeCombinationsAndEquipmentColumn>(modelYearsAndEquipmentColumn,
                        modelYearsAndEquipmentColumn.getNameTexts().values());
        
        EquipmentColumn equipmentColumn = 
        		new EquipmentColumn(availableLocales, vehicleSelectionChangeSessionDTO.getData()
                        .getYearCodeCombination(), vehicleSelectionChangeSessionDTO.getData().getAndTerms(),
                        maxElemToDisplay);
        
        this.equipment = new UIListElementI18N<EquipmentColumn>(equipmentColumn,
                equipmentColumn.getNameTexts().values());

        ConsumerCountriesColumn consumerCountriesColumn =
                new ConsumerCountriesColumn(availableLocales, new ArrayList<String>(vehicleSelectionChangeSessionDTO
                        .getData().getConsumerCountryCodes()), maxElemToDisplay, mbCountries);

        this.consumerCountries =
                new UIListElementI18N<ConsumerCountriesColumn>(consumerCountriesColumn, consumerCountriesColumn
                        .getNameTexts().values());

        this.vehicleSelectionChangeSessionDTO = vehicleSelectionChangeSessionDTO;

    }

    /**
     * Gets the description.
     *
     * @return the description
     */
    public UIListElementI18N<DescriptionColumn> getDescription() {
        return description;
    }

    /**
     * Gets the modelSeries.
     *
     * @return the modelSeries
     */
    public UIListElementI18N<ModelSeriesColumn> getModelSeries() {
        return modelSeries;
    }

    
    /**
     * Gets the SalesType.
     *
     * @return the SalesType
     */
    public UIListElementI18N<SalesTypeColumn> getSalesType() {
        return salesType;
    }
    
    /**
     * Gets the yearCodeCombinationsAndEquipment.
     *
     * @return the yearCodeCombinationsAndEquipment
     */
    public UIListElementI18N<YearCodeCombinationsAndEquipmentColumn> getYearCodeCombinationsAndEquipment() {
        return yearCodeCombinationsAndEquipment;
    }
    
    /**
     * Gets the equipment.
     *
     * @return the equipment
     */
    public UIListElementI18N<EquipmentColumn> getEquipment() {
        return equipment;
    }

    /**
     * Gets the consumerCountries.
     *
     * @return the consumerCountries
     */
    public UIListElementI18N<ConsumerCountriesColumn> getConsumerCountries() {
        return consumerCountries;
    }

    /**
     * Sets the vehicleSelectionChangeSessionDTO.
     *
     * @param vsChangeSessionDTO the vehicleSelectionChangeSessionDTO to set
     */
    public void setVehicleSelectionChangeSessionDTO(final VehicleSelectionChangeSessionDTO vsChangeSessionDTO) {
        this.vehicleSelectionChangeSessionDTO = vsChangeSessionDTO;
    }

    /**
     * Gets the serviceAssignmentRuleRDTO.
     *
     * @return the serviceAssignmentRuleRDTO
     */
    public VehicleSelectionChangeSessionDTO getVehicleSelectionChangeSession() {
        return vehicleSelectionChangeSessionDTO;
    }

    /**
     * Returns the set value for {@link #businessKey}.
     *
     * @return the {@link #businessKey}
     */
    public String getArtificialBusinessKey() {
        return businessKey;
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().appendSuper(super.hashCode()).toHashCode();
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        return new EqualsBuilder().appendSuper(super.equals(obj)).isEquals();
    }

    @Override
    public String toString() {
        ToStringBuilder builder = new ToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE);
        builder.appendSuper(super.toString());
        builder.append("businessKey", businessKey);
        builder.append("modelSeries", modelSeries);
        builder.append("salesType",salesType);
        builder.append("description", description);
        builder.append("yearCodeCombinationsAndEquipment", yearCodeCombinationsAndEquipment);
        builder.append("equipment",equipment);
        builder.append("consumerCountries", consumerCountries);
        builder.append("vehicleSelectionChangeSessionDTO", vehicleSelectionChangeSessionDTO);
        return builder.toString();
    }
}
