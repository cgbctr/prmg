package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.LocaleUtils;

import com.daimler.soe.changesession.services.business.service.VehicleSelectionChangeSessionDTO;
import com.daimler.soe.foundation.messages.MessageHelper;
import com.daimler.soe.techbase.dtos.NameI18NDTO;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionDTO;

public class SalesTypeColumn {
	
	private static final String SLASH = " / ";

    private static final String SLASH_WITH_DASH = " / -";

    private static final String DASH = "-";

    private static final String TAG_BR = "<br/>";

    private static final String TAG_BOLD_OPEN = "<b>";

    private static final String TAG_BOLD_CLOSED = "</b>";

    private static final String MODEL_SERIES_KEY = "GENERAL.modelseries";

    private static final String WILDCARD = "SOE_VehicleSelectionsDialog.wildcard";

    private static final String ALL = "SOE_VehicleSelectionsDialog.allcountriesavailable";

    private static final String NST = "GENERAL.nst";

    private static final int INT_2 = 2;

    private static final int INT_3 = 3;

    private static final int INT_6 = 6;

    private static final int INT_7 = 7;

    /** Contains i18n values. */
    private final Map<String, NameI18NDTO> nameTexts = new HashMap<String, NameI18NDTO>();

    private final String modelSeries;

    private final String baumusterWildcard;

    private final boolean useModelSeriesCondition;

    private Collection<String> nstSet;

    private final String[] availableLocales;

    SalesTypeColumn(String[] availableLocales, VehicleSelectionChangeSessionDTO vehicleSelectionChangeSessionDTO) {

        VehicleSelectionDTO vehicleSelectionDTO = vehicleSelectionChangeSessionDTO.getData();
        this.modelSeries = StringUtils.join(vehicleSelectionDTO.getModelSeriesIds(), ',');
        this.useModelSeriesCondition = vehicleSelectionDTO.isUseModelSeriesCondition();

        if (null == vehicleSelectionDTO.getNsts()) {
            nstSet = new HashSet<String>();
        } else {
            nstSet = vehicleSelectionDTO.getNsts();
        }

        baumusterWildcard = getBaumusterWildcard(vehicleSelectionChangeSessionDTO);
        this.availableLocales = availableLocales;
        build();
    }

    private void build() {

        for (int i = 0; i < availableLocales.length; i++) {
            final String locale = availableLocales[i];
            StringBuilder textInCol = new StringBuilder();
     /*       // Model series description
            textInCol.append(TAG_BOLD_OPEN);
            textInCol.append(MessageHelper.getI18NText(MODEL_SERIES_KEY, LocaleUtils.toLocale(locale)));
            textInCol.append(TAG_BOLD_CLOSED);
            textInCol.append(TAG_BR);
            // Model series values


            if (!useModelSeriesCondition) {
                textInCol.append(MessageHelper.getI18NText(ALL, LocaleUtils.toLocale(locale)));
                nameTexts.put(locale, new NameI18NDTO(locale, textInCol.toString()));
            } else {
                textInCol.append(this.modelSeries);
            }
            textInCol.append(TAG_BR);
	*/
            textInCol = setSalesTypeCondition(textInCol, locale);
            nameTexts.put(locale, new NameI18NDTO(locale, textInCol.toString()));
        }
    }

    private StringBuilder setSalesTypeCondition(StringBuilder textInCol, String locale) {
        // Sales type condition description
        textInCol.append(TAG_BR);
        textInCol.append(TAG_BR);
        textInCol.append(TAG_BOLD_OPEN);
        textInCol.append(MessageHelper.getI18NText(WILDCARD, LocaleUtils.toLocale(locale)));

        if (CollectionUtils.isNotEmpty(nstSet)) {
            textInCol.append(SLASH);
            textInCol.append(MessageHelper.getI18NText(NST, LocaleUtils.toLocale(locale)));
        }
        textInCol.append(TAG_BOLD_CLOSED);
        textInCol.append(TAG_BR);

        if (CollectionUtils.isEmpty(nstSet) && StringUtils.isNotBlank(baumusterWildcard)) {
            addBaumusterWildcard(textInCol);
            textInCol.append(SLASH_WITH_DASH);
        }
        if (CollectionUtils.isEmpty(nstSet) && StringUtils.isBlank(baumusterWildcard)) {
            textInCol.append(DASH);
            textInCol.append(SLASH_WITH_DASH);
        } else {
            for (String nst : nstSet) {
                addBaumusterWildcard(textInCol);
                textInCol.append(SLASH + nst);
                textInCol.append(TAG_BR);
            }
        }
        return textInCol;
    }

    private String getBaumusterWildcard(VehicleSelectionChangeSessionDTO vehicleSelectionChangeSessionDTO) {
        StringBuilder baumusterStringBuilder = new StringBuilder();
        if (StringUtils.isNotBlank(vehicleSelectionChangeSessionDTO.getData().getBaumusterWildcard())) {
            baumusterStringBuilder.append(vehicleSelectionChangeSessionDTO.getData().getBaumusterWildcard());
            if (baumusterStringBuilder.length() == INT_7) {
                baumusterStringBuilder.insert(INT_6, ".").insert(INT_3, ".");
            } else if (baumusterStringBuilder.length() > INT_2) {
                baumusterStringBuilder.insert(INT_3, ".").append('*');
            }
        }
        return baumusterStringBuilder.toString();
    }

    /**
     * Gets the nameTexts.
     *
     * @return nameTexts
     */
    public Map<String, NameI18NDTO> getNameTexts() {
        return nameTexts;
    }

    private StringBuilder addBaumusterWildcard(StringBuilder textInCol) {
        if (StringUtils.isNotBlank(baumusterWildcard)) {
            return textInCol.append(baumusterWildcard);
        }
        return textInCol.append(DASH);
    }


}
