/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: VehicleSelectionsDialogCore          $Id: $

    FileType: Class

    Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import com.daimler.soe.foundation.authorizationsupport.base.ResourceConstants;
import com.daimler.soe.foundation.data.AbstractDialogCore;
import com.daimler.soe.foundation.data.AccessPrivilegesService;
import com.sdm.quasar.client.jsf.dialog.features.JSFDialogFeature;
import com.sdm.quasar.common.DisposeException;

/**
 * This dialog is used to manage the service assignment rules.
 * 
 * @author Capgemini
 */
public class VehicleSelectionsDialogCore extends AbstractDialogCore {

    private VehicleSelectionsDialogStateManager stateManager;

    private VehicleSelectionsDialogDataManager dataManager;

    private VehicleSelectionsDialogActionManager actionManager;

    @Override
    protected void init() {
        super.init();
        dataManager = getComponentControl().requireFeature(VehicleSelectionsDialogDataManager.class);
        actionManager = getComponentControl().requireFeature(VehicleSelectionsDialogActionManager.class);
        stateManager = getComponentControl().requireFeature(VehicleSelectionsDialogStateManager.class);
        stateManager.setAccessPrivileges(getComponentControl().findService(AccessPrivilegesService.class)
                .getAccessPrivileges(getResourceName()));
    }

    @Override
    protected void dispose() throws DisposeException {
        // do nothing
    }

    @Override
    protected void prepare() {
        JSFDialogFeature bindingFeature = getComponentControl().requireFeature(JSFDialogFeature.class);
        bindingFeature.setBackingBean(this);
        bindingFeature.setDataManager(dataManager);
        bindingFeature.setActionManager(actionManager);
        bindingFeature.setStateManager(stateManager);
    }

    @Override
    protected String getResourceName() {
        return ResourceConstants.DlgServicesConstants.SERV_ASS_RULES_DIALOG;
    }

}
