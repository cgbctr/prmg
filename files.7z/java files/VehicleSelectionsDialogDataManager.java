/*+***********************************************************************
    Copyright (c) 2013 Daimler Corporation. All rights reserved.
 **************************************************************************

    File: package-info          $Id: $

    FileType: Package information file      Class

    Version:        $Revision: $

 **************************************************************************/
package com.daimler.soe.vehicleproduct.vehicleselections.impl;

import java.util.ArrayList;
import java.util.List;
import com.daimler.soe.changesession.services.business.service.VehicleSelectionChangeSessionDTO;
import com.daimler.soe.dialogfacade.mbconnectcountries.business.service.MBconnectCountriesFacadeBs;
import com.daimler.soe.foundation.data.AbstractOverviewDataManager;
import com.daimler.soe.foundation.data.UIListElementI18N;
import com.daimler.soe.foundation.utilities.ServiceLocatorFactory;
import com.daimler.soe.mbconnectcountries.mbconnectcountries.business.service.MBcCountryDTO;
import com.daimler.soe.techbase.dtos.NameI18NDTO;
import com.daimler.soe.vehicleproduct.vehicleselectionmasterdata.business.service.VehicleSelectionDTO;

/**
 * The Service Assignment Rules Dialog Data Manager.
 * 
 * @author Capgemini
 */
public class VehicleSelectionsDialogDataManager extends
        AbstractOverviewDataManager<UIListElementI18N<VehicleSelectionDataTableElement>> {

    @Override
    public void init() {
        // do nothing
    }

    @Override
    public void dispose() {
        // do nothing
    }

    @Override
    protected void prepare() {
        // do nothing
    }

    void populateVehicleSelectionsList(List<VehicleSelectionChangeSessionDTO> vehicleSelectionSessionList) {

        ArrayList<UIListElementI18N<VehicleSelectionDataTableElement>> vehicleSelectionsList =
                new ArrayList<UIListElementI18N<VehicleSelectionDataTableElement>>();
        MBconnectCountriesFacadeBs countriesBs =
            ServiceLocatorFactory.getServiceLocator().getService(MBconnectCountriesFacadeBs.class);
        List<MBcCountryDTO> mbCountries = countriesBs.getMBconnectCountries();
        String[] availableLocales = getAvailableLocales();
        int maxElementsToDisplayForVehicleSelectionsOverview = getMaxElementsToDisplayForRulesOverview();

        for (VehicleSelectionChangeSessionDTO vehicleSelectionSession : vehicleSelectionSessionList) {

            VehicleSelectionDataTableElement row =
                    new VehicleSelectionDataTableElement(availableLocales, vehicleSelectionSession,
                            maxElementsToDisplayForVehicleSelectionsOverview, mbCountries);

            vehicleSelectionsList.add(new UIListElementI18N<VehicleSelectionDataTableElement>(row,
                    new ArrayList<NameI18NDTO>()));
        }

        setDataList(vehicleSelectionsList);
    }

    /**
     * Method to validate the delete.
     * 
     * @return {@link Boolean}
     */
    public boolean validateDelete() {
        for (UIListElementI18N<VehicleSelectionDataTableElement> ruleElem : getDataList()) {
            if (ruleElem.isChecked()) {
                return Boolean.TRUE;
            }
        }
        return Boolean.FALSE;
    }

    /**
     * returns the list of service assignment rules that are checked for deletion.
     * 
     * @return the {@link List<VehicleSelectionRDTO>}
     */
    public List<VehicleSelectionChangeSessionDTO> getVehicleSelectionsListForDeletion() {

        List<VehicleSelectionChangeSessionDTO> vehicleSelections = new ArrayList<VehicleSelectionChangeSessionDTO>();

        for (UIListElementI18N<VehicleSelectionDataTableElement> selectionElem : getDataList()) {
            if (selectionElem.isChecked()) {
                vehicleSelections.add(selectionElem.getContent().getVehicleSelectionChangeSession());
            }
        }
        return vehicleSelections;
    }

    /**
     * Create a new Service Assignment Rule for add dialog and return it.
     * 
     * @return the vehicleSelectionForAdd
     */
    public VehicleSelectionChangeSessionDTO getVehicleSelectionForAdd() {
        VehicleSelectionDTO elem = new VehicleSelectionDTO();
        VehicleSelectionChangeSessionDTO rValue = new VehicleSelectionChangeSessionDTO(elem);
        return rValue;
    }

    /**
     * Returns the service assignment rule as DTO.
     * 
     * @return VehicleSelectionRDTO
     */
    public VehicleSelectionChangeSessionDTO getVehicleSelectionChangeSession() {
        return getData().getContent().getVehicleSelectionChangeSession();
    }

    /**
     * Gets for vehicleSelection.
     * 
     * @return the vehicleSelection
     */
    public UIListElementI18N<VehicleSelectionDataTableElement> getVehicleSelection() {
        return getData();
    }

}
